
  # Diseñar casino online AleandroGarsiajackpot

  This is a code bundle for Diseñar casino online AleandroGarsiajackpot. The original project is available at https://www.figma.com/design/hO5mfjJhdyNK63oXKF06TE/Dise%C3%B1ar-casino-online-AleandroGarsiajackpot.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  