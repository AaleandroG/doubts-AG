import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { toast } from 'sonner';

interface User {
  id: string;
  name: string;
  balance: number; // Fichas Jackpot
  lastDailyReward: string | null;
}

interface UserContextType {
  user: User | null;
  updateBalance: (amount: number) => void;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

const DAILY_COINS = 1000; // Fichas diarias automáticas

export function UserProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [hasShownWelcome, setHasShownWelcome] = useState(false);

  // Crear usuario automático al iniciar
  useEffect(() => {
    const savedUser = localStorage.getItem('casino_auto_user');
    const today = new Date().toDateString();
    
    if (savedUser) {
      const parsedUser = JSON.parse(savedUser);
      const lastRewardDate = parsedUser.lastDailyReward ? new Date(parsedUser.lastDailyReward).toDateString() : null;
      
      // Si es un nuevo día, dar nuevas fichas
      if (lastRewardDate !== today) {
        const updatedUser = {
          ...parsedUser,
          balance: DAILY_COINS,
          lastDailyReward: new Date().toISOString(),
        };
        setUser(updatedUser);
        localStorage.setItem('casino_auto_user', JSON.stringify(updatedUser));
        
        if (!hasShownWelcome) {
          toast.success('¡Nuevas fichas diarias!', {
            description: `Has recibido ${DAILY_COINS} Fichas Jackpot para hoy 🎁`,
          });
          setHasShownWelcome(true);
        }
      } else {
        setUser(parsedUser);
      }
    } else {
      // Crear nuevo usuario automáticamente
      const newUser: User = {
        id: Date.now().toString(),
        name: 'Jugador',
        balance: DAILY_COINS,
        lastDailyReward: new Date().toISOString(),
      };
      setUser(newUser);
      localStorage.setItem('casino_auto_user', JSON.stringify(newUser));
      
      if (!hasShownWelcome) {
        toast.success('¡Bienvenido! 🎰', {
          description: `Tienes ${DAILY_COINS} Fichas Jackpot para jugar gratis`,
        });
        setHasShownWelcome(true);
      }
    }
  }, []);

  // Guardar usuario en localStorage cuando cambie
  useEffect(() => {
    if (user) {
      localStorage.setItem('casino_auto_user', JSON.stringify(user));
    }
  }, [user]);

  const updateBalance = (amount: number) => {
    if (!user) return;

    const newBalance = user.balance + amount;
    const updatedUser = { ...user, balance: Math.max(0, newBalance) };
    setUser(updatedUser);

    // Si se queda sin fichas, recordarle que vuelva mañana
    if (updatedUser.balance === 0) {
      toast.info('¡Te has quedado sin fichas!', {
        description: 'Vuelve mañana para recibir 1000 fichas nuevas 🎁',
      });
    }
  };

  const value: UserContextType = {
    user,
    updateBalance,
  };

  return <UserContext.Provider value={value}>{children}</UserContext.Provider>;
}

export function useUser() {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
}
