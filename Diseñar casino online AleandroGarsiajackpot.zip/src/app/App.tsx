import { UserProvider } from './contexts/UserContext';
import { TemuAd } from './components/TemuAd';
import { FeaturedGames } from './components/FeaturedGames';
import { UserBalance } from './components/UserBalance';
import { Toaster } from './components/ui/sonner';
import { Coins } from 'lucide-react';

export default function App() {
  return (
    <UserProvider>
      <div className="min-h-screen bg-zinc-950">
        {/* Header Simple */}
        <header className="bg-gradient-to-r from-zinc-900 via-zinc-800 to-zinc-900 border-b border-yellow-500/20 sticky top-0 z-50 backdrop-blur-lg">
          <div className="container mx-auto px-4 py-6">
            <div className="flex items-center justify-center gap-3">
              <Coins className="w-10 h-10 text-yellow-500" />
              <h1 className="text-3xl md:text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 via-yellow-500 to-orange-500">
                AleandroGarsiajackpot
              </h1>
            </div>
            <p className="text-center text-zinc-400 text-sm mt-2">
              🎰 Casino Virtual Gratis - 1000 Fichas Diarias 🎁
            </p>
          </div>
        </header>

        {/* User Balance Display */}
        <UserBalance />

        <main className="container mx-auto px-4 py-8 space-y-8">
          {/* ANUNCIO TEMU GRANDE #1 */}
          <TemuAd variant="large" />

          {/* ANUNCIO TEMU BANNER #1 */}
          <TemuAd variant="banner" />

          {/* JUEGOS DESTACADOS */}
          <FeaturedGames />

          {/* ANUNCIO TEMU BANNER #2 */}
          <TemuAd variant="banner" />

          {/* ANUNCIO TEMU GRANDE #2 */}
          <TemuAd variant="large" />

          {/* ANUNCIOS TEMU EN FILA */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <TemuAd variant="sidebar" />
            <TemuAd variant="sidebar" />
          </div>

          {/* ANUNCIO TEMU BANNER #3 */}
          <TemuAd variant="banner" />

          {/* MÁS ANUNCIOS INLINE */}
          <div className="space-y-4">
            <TemuAd variant="inline" />
            <TemuAd variant="inline" />
            <TemuAd variant="inline" />
          </div>

          {/* ANUNCIO TEMU GRANDE #3 */}
          <TemuAd variant="large" />

          {/* Footer Simple con Temu */}
          <footer className="bg-zinc-900 rounded-2xl p-8 text-center space-y-6">
            <TemuAd variant="banner" />
            
            <div className="border-t border-zinc-800 pt-6 space-y-3">
              <h3 className="text-yellow-500 font-bold text-xl">AleandroGarsiajackpot</h3>
              <p className="text-zinc-400 text-sm">
                🎮 Casino Virtual Gratuito - Solo Entretenimiento
              </p>
              <p className="text-zinc-500 text-xs">
                💰 Moneda ficticia sin valor real | +18 | Juega responsablemente
              </p>
              <p className="text-zinc-600 text-xs mt-4">
                Este sitio es gratuito gracias a nuestros anunciantes como TEMU 🛍️
              </p>
            </div>

            <TemuAd variant="inline" />
          </footer>
        </main>

        {/* Toast Notifications */}
        <Toaster
          position="top-right"
          toastOptions={{
            style: {
              background: '#27272a',
              color: '#fafafa',
              border: '1px solid #3f3f46',
            },
          }}
        />
      </div>
    </UserProvider>
  );
}