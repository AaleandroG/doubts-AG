import { Trophy, TrendingUp, Flame, Star, Award } from 'lucide-react';
import { Button } from './ui/button';
import { toast } from 'sonner';

export function TopGamesRanking() {
  const handlePlayGame = (gameName: string) => {
    toast.info(`Cargando ${gameName}...`, {
      description: 'Inicia sesión para jugar',
    });
  };

  const topGames = [
    {
      rank: 1,
      name: 'Mega Fortune™ Deluxe',
      provider: 'NetEnt',
      rtp: '96.6%',
      rating: 4.9,
      popularity: 98,
      image: 'https://images.unsplash.com/photo-1596838132731-3301c3fd4317?w=200&h=150&fit=crop',
      category: 'Slots',
      maxWin: '50,000x',
      badge: 'trending',
    },
    {
      rank: 2,
      name: 'Blackjack Premium VIP',
      provider: 'Evolution',
      rtp: '99.5%',
      rating: 4.8,
      popularity: 95,
      image: 'https://images.unsplash.com/photo-1541278107931-e006523892df?w=200&h=150&fit=crop',
      category: 'Cartas',
      maxWin: '100x',
      badge: 'hot',
    },
    {
      rank: 3,
      name: 'Ruleta Europea Pro',
      provider: 'Pragmatic Play',
      rtp: '97.3%',
      rating: 4.8,
      popularity: 93,
      image: 'https://images.unsplash.com/photo-1511193311914-0346f16efe90?w=200&h=150&fit=crop',
      category: 'Ruleta',
      maxWin: '35x',
      badge: 'hot',
    },
    {
      rank: 4,
      name: 'Video Poker Jacks or Better',
      provider: 'NetEnt',
      rtp: '99.5%',
      rating: 4.7,
      popularity: 90,
      image: 'https://images.unsplash.com/photo-1571902943202-507ec2618e8f?w=200&h=150&fit=crop',
      category: 'Video Poker',
      maxWin: '250x',
      badge: 'new',
    },
    {
      rank: 5,
      name: 'Lucky Fruits™ 777',
      provider: 'Play\'n GO',
      rtp: '96.8%',
      rating: 4.7,
      popularity: 88,
      image: 'https://images.unsplash.com/photo-1516975080664-ed2fc6a32937?w=200&h=150&fit=crop',
      category: 'Slots Clásicas',
      maxWin: '25,000x',
      badge: 'trending',
    },
  ];

  const getBadgeColor = (badge: string) => {
    switch (badge) {
      case 'trending':
        return 'bg-blue-500 text-white';
      case 'hot':
        return 'bg-red-500 text-white animate-pulse';
      case 'new':
        return 'bg-green-500 text-black';
      default:
        return 'bg-zinc-700 text-white';
    }
  };

  const getBadgeIcon = (badge: string) => {
    switch (badge) {
      case 'trending':
        return <TrendingUp className="w-3 h-3" />;
      case 'hot':
        return <Flame className="w-3 h-3" />;
      case 'new':
        return <Star className="w-3 h-3" />;
      default:
        return null;
    }
  };

  return (
    <section id="rankings" className="py-16 lg:py-24 bg-zinc-900">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <Trophy className="w-8 h-8 text-yellow-500" />
            <div>
              <h2 className="text-3xl lg:text-4xl font-bold text-white">
                Top 5 Juegos del Mes
              </h2>
              <p className="text-zinc-400 mt-1">Ranking según jugadores, RTP y valoraciones</p>
            </div>
          </div>
        </div>

        {/* Rankings Table */}
        <div className="space-y-4">
          {topGames.map((game) => (
            <div
              key={game.rank}
              className="bg-zinc-800 rounded-xl overflow-hidden border border-zinc-700 hover:border-yellow-500/50 transition-all duration-300 hover:shadow-lg hover:shadow-yellow-500/10"
            >
              <div className="flex flex-col md:flex-row gap-4 p-4 lg:p-6">
                {/* Rank Badge */}
                <div className="flex md:flex-col items-center md:items-center gap-3 md:gap-2">
                  <div
                    className={`flex items-center justify-center w-12 h-12 rounded-full font-bold text-xl ${
                      game.rank === 1
                        ? 'bg-gradient-to-br from-yellow-400 to-yellow-600 text-black'
                        : game.rank === 2
                        ? 'bg-gradient-to-br from-zinc-300 to-zinc-400 text-black'
                        : game.rank === 3
                        ? 'bg-gradient-to-br from-amber-600 to-amber-800 text-white'
                        : 'bg-zinc-700 text-white'
                    }`}
                  >
                    #{game.rank}
                  </div>
                  {game.rank <= 3 && (
                    <Award className={`w-6 h-6 ${
                      game.rank === 1 ? 'text-yellow-500' : 
                      game.rank === 2 ? 'text-zinc-300' : 
                      'text-amber-600'
                    }`} />
                  )}
                </div>

                {/* Game Image */}
                <div className="relative w-full md:w-32 h-32 md:h-24 rounded-lg overflow-hidden flex-shrink-0">
                  <img
                    src={game.image}
                    alt={game.name}
                    className="w-full h-full object-cover"
                  />
                  <div className={`absolute top-2 left-2 flex items-center gap-1 px-2 py-1 rounded-full text-xs font-bold ${getBadgeColor(game.badge)}`}>
                    {getBadgeIcon(game.badge)}
                    {game.badge.toUpperCase()}
                  </div>
                </div>

                {/* Game Info */}
                <div className="flex-1">
                  <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-2 mb-3">
                    <div>
                      <h3 className="text-xl font-bold text-white mb-1">
                        {game.name}
                      </h3>
                      <p className="text-sm text-zinc-400">
                        {game.provider} • {game.category}
                      </p>
                    </div>
                    
                    {/* Rating */}
                    <div className="flex items-center gap-1 bg-zinc-700 px-3 py-1 rounded-full">
                      <Star className="w-4 h-4 text-yellow-500 fill-current" />
                      <span className="text-white font-bold">{game.rating}</span>
                    </div>
                  </div>

                  {/* Stats Grid */}
                  <div className="grid grid-cols-3 md:grid-cols-4 gap-3 mb-4">
                    <div className="bg-zinc-900 rounded-lg p-2 text-center">
                      <p className="text-xs text-zinc-400 mb-1">RTP</p>
                      <p className="text-sm font-bold text-green-400">{game.rtp}</p>
                    </div>
                    <div className="bg-zinc-900 rounded-lg p-2 text-center">
                      <p className="text-xs text-zinc-400 mb-1">Max Win</p>
                      <p className="text-sm font-bold text-yellow-400">{game.maxWin}</p>
                    </div>
                    <div className="bg-zinc-900 rounded-lg p-2 text-center">
                      <p className="text-xs text-zinc-400 mb-1">Popularidad</p>
                      <p className="text-sm font-bold text-blue-400">{game.popularity}%</p>
                    </div>
                    <div className="bg-zinc-900 rounded-lg p-2 text-center hidden md:block">
                      <p className="text-xs text-zinc-400 mb-1">Categoría</p>
                      <p className="text-sm font-bold text-purple-400">{game.category}</p>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex gap-2">
                    <Button
                      onClick={() => handlePlayGame(game.name)}
                      className="flex-1 md:flex-initial bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-black font-bold"
                    >
                      Jugar Ahora
                    </Button>
                    <Button
                      variant="outline"
                      className="border-zinc-700 text-white hover:bg-zinc-700"
                      onClick={() => toast.info('Ver reseña completa')}
                    >
                      Reseña
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* View All Button */}
        <div className="text-center mt-8">
          <Button
            variant="outline"
            className="border-yellow-500 text-yellow-500 hover:bg-yellow-500 hover:text-black font-bold px-8 py-6"
            onClick={() => toast.info('Ver ranking completo')}
          >
            Ver Ranking Completo
          </Button>
        </div>
      </div>
    </section>
  );
}