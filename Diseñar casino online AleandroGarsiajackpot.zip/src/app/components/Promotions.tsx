import { Button } from './ui/button';
import { Gift, Ticket, Trophy, Zap } from 'lucide-react';
import { toast } from 'sonner';
import { useState } from 'react';

export function Promotions() {
  const [email, setEmail] = useState('');

  const handlePromotionClick = (promoTitle: string) => {
    toast.success(`¡Promoción activada!`, {
      description: `${promoTitle} ha sido añadida a tu cuenta`,
    });
  };

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      toast.success('¡Suscripción exitosa!', {
        description: 'Recibirás nuestras mejores ofertas en tu correo',
      });
      setEmail('');
    }
  };

  const promotions = [
    {
      icon: <Gift className="w-12 h-12" />,
      title: 'Bono de Bienvenida',
      description: '1000 Fichas Jackpot gratis al registrarte',
      ctaText: 'Reclamar',
      badge: 'Popular',
    },
    {
      icon: <Ticket className="w-12 h-12" />,
      title: 'Tiradas Gratis Diarias',
      description: 'Reclama fichas extra cada 24 horas',
      ctaText: 'Activar',
    },
    {
      icon: <Trophy className="w-12 h-12" />,
      title: 'Torneo Semanal',
      description: 'Compite y gana hasta 5,000 fichas extra',
      ctaText: 'Participar',
      badge: 'Nuevo',
    },
    {
      icon: <Zap className="w-12 h-12" />,
      title: 'Cashback del 10%',
      description: 'Recupera parte de tus fichas perdidas',
      ctaText: 'Activar',
    },
  ];

  return (
    <section id="promotions" className="py-16 lg:py-24 bg-zinc-950">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold text-white mb-4">
            Promociones y Bonos
          </h2>
          <p className="text-zinc-400 text-lg max-w-2xl mx-auto">
            Aprovecha nuestras increíbles ofertas y multiplica tus ganancias
          </p>
        </div>

        {/* Promotions Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {promotions.map((promo, index) => (
            <div
              key={index}
              className="bg-zinc-800 rounded-2xl overflow-hidden border border-zinc-700 hover:border-yellow-500/50 transition-all duration-300 hover:transform hover:scale-105"
            >
              {/* Header with gradient */}
              <div className="bg-gradient-to-br from-yellow-500 to-orange-500 p-6">
                {promo.icon}
                {promo.badge && (
                  <span className="absolute top-3 right-3 bg-black/30 backdrop-blur-sm px-3 py-1 rounded-full text-xs text-white font-semibold">
                    {promo.badge}
                  </span>
                )}
              </div>

              {/* Content */}
              <div className="p-6">
                <h3 className="text-xl font-bold text-white mb-2">
                  {promo.title}
                </h3>
                <p className="text-zinc-400 mb-6">
                  {promo.description}
                </p>

                <Button
                  onClick={() => handlePromotionClick(promo.title)}
                  className="w-full bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-black font-semibold"
                >
                  {promo.ctaText}
                </Button>

                <p className="text-xs text-zinc-500 mt-3 text-center">
                  T&C aplicables
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* CTA Banner */}
        <div className="mt-12 bg-gradient-to-r from-yellow-500 via-yellow-600 to-orange-500 rounded-2xl p-8 lg:p-12 text-center">
          <h3 className="text-2xl lg:text-3xl font-bold text-black mb-4">
            ¿No quieres perderte ninguna promoción?
          </h3>
          <p className="text-lg text-black/80 mb-6">
            Suscríbete a nuestro newsletter y recibe ofertas exclusivas
          </p>
          <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
            <input
              type="email"
              placeholder="Tu correo electrónico"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="flex-1 px-4 py-3 rounded-lg bg-white/20 backdrop-blur-sm border border-black/20 text-black placeholder-black/60 focus:outline-none focus:ring-2 focus:ring-black/30"
            />
            <Button
              onClick={handleNewsletterSubmit}
              className="bg-black hover:bg-black/90 text-white font-semibold px-8"
            >
              Suscribirse
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}