import { ShoppingBag, ExternalLink, Sparkles } from 'lucide-react';
import { Button } from './ui/button';

interface TemuAdProps {
  variant?: 'banner' | 'sidebar' | 'inline' | 'large';
  className?: string;
}

export function TemuAd({ variant = 'banner', className = '' }: TemuAdProps) {
  const temuLink = 'https://temu.to/k/ey271blgwm6';

  const handleClick = () => {
    window.open(temuLink, '_blank', 'noopener,noreferrer');
  };

  if (variant === 'banner') {
    return (
      <div className={`bg-gradient-to-r from-orange-500 via-red-500 to-pink-500 rounded-xl overflow-hidden ${className}`}>
        <div className="flex flex-col md:flex-row items-center justify-between p-4 md:p-6 gap-4">
          <div className="flex items-center gap-3">
            <div className="bg-white rounded-full p-3 flex-shrink-0">
              <ShoppingBag className="w-6 h-6 text-orange-500" />
            </div>
            <div className="text-white">
              <div className="flex items-center gap-2 mb-1">
                <h3 className="font-bold text-lg">¡Compra en TEMU!</h3>
                <Sparkles className="w-4 h-4 animate-pulse" />
              </div>
              <p className="text-sm text-white/90">
                Descuentos increíbles en miles de productos 🎁
              </p>
            </div>
          </div>
          <Button
            onClick={handleClick}
            className="bg-white hover:bg-gray-100 text-orange-600 font-bold px-6 py-3 flex items-center gap-2 flex-shrink-0"
          >
            Ver Ofertas
            <ExternalLink className="w-4 h-4" />
          </Button>
        </div>
      </div>
    );
  }

  if (variant === 'sidebar') {
    return (
      <button
        onClick={handleClick}
        className={`w-full bg-gradient-to-br from-orange-500 to-pink-500 rounded-xl p-6 text-white hover:scale-105 transition-transform ${className}`}
      >
        <div className="flex items-center justify-center gap-2 mb-3">
          <ShoppingBag className="w-8 h-8" />
          <Sparkles className="w-5 h-5 animate-pulse" />
        </div>
        <h3 className="font-bold text-xl mb-2">TEMU</h3>
        <p className="text-sm mb-4">¡Compra como multimillonario!</p>
        <div className="bg-white/20 backdrop-blur-sm rounded-lg py-2 px-4 text-xs font-semibold">
          👉 Ver Ofertas Especiales
        </div>
      </button>
    );
  }

  if (variant === 'large') {
    return (
      <div className={`bg-gradient-to-br from-orange-600 via-red-600 to-pink-600 rounded-2xl overflow-hidden ${className}`}>
        <div className="p-8 lg:p-12 text-center text-white">
          <div className="flex items-center justify-center gap-3 mb-4">
            <ShoppingBag className="w-12 h-12" />
            <Sparkles className="w-8 h-8 animate-pulse" />
          </div>
          <h2 className="text-3xl lg:text-4xl font-bold mb-4">
            ¿Te gustan las fichas gratis?
          </h2>
          <p className="text-xl mb-2 text-white/90">
            ¡Gracias a anunciantes como TEMU podemos ofrecerte todo GRATIS!
          </p>
          <p className="text-lg mb-6 text-white/80">
            Descubre miles de productos con descuentos increíbles 🛍️
          </p>
          <Button
            onClick={handleClick}
            size="lg"
            className="bg-white hover:bg-gray-100 text-orange-600 font-bold text-lg px-8 py-6"
          >
            <ShoppingBag className="w-5 h-5 mr-2" />
            Explorar TEMU Ahora
            <ExternalLink className="w-5 h-5 ml-2" />
          </Button>
          <p className="text-xs mt-4 text-white/60">
            Publicidad • Al hacer clic apoyas el casino gratuito
          </p>
        </div>
      </div>
    );
  }

  // variant === 'inline'
  return (
    <button
      onClick={handleClick}
      className={`bg-gradient-to-r from-orange-500 to-pink-500 rounded-lg p-4 text-white hover:shadow-lg hover:shadow-orange-500/20 transition-all flex items-center gap-3 w-full ${className}`}
    >
      <div className="bg-white rounded-full p-2 flex-shrink-0">
        <ShoppingBag className="w-5 h-5 text-orange-500" />
      </div>
      <div className="flex-1 text-left">
        <p className="font-bold text-sm">Publicidad: TEMU</p>
        <p className="text-xs text-white/90">Descuentos hasta 90% OFF</p>
      </div>
      <ExternalLink className="w-4 h-4 flex-shrink-0" />
    </button>
  );
}
