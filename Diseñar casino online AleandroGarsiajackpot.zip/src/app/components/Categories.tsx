import { Dices, Tv, TrendingUp, Layers, Sparkles, ChevronRight } from 'lucide-react';
import { Button } from './ui/button';
import { toast } from 'sonner';

export function Categories() {
  const handleCategoryClick = (categoryName: string) => {
    toast.info(`Explorando ${categoryName}`, {
      description: 'Cargando juegos de esta categoría...',
    });
    
    // Scroll to games section
    const element = document.querySelector('#games');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const categories = [
    {
      icon: Dices,
      title: 'Slots',
      description: 'Más de 1000 máquinas tragamonedas',
      image: 'https://images.unsplash.com/photo-1582656975064-04e9452fc60e?w=800',
      color: 'from-purple-500 to-purple-700',
    },
    {
      icon: Tv,
      title: 'Casino en Vivo',
      description: 'Crupieres reales 24/7',
      image: 'https://images.unsplash.com/photo-1633629544357-14223c9837d2?w=800',
      color: 'from-red-500 to-red-700',
    },
    {
      icon: TrendingUp,
      title: 'Jackpots',
      description: 'Premios acumulados millonarios',
      image: 'https://images.unsplash.com/photo-1759701547315-cc8b7f2100f3?w=800',
      color: 'from-yellow-500 to-yellow-700',
    },
    {
      icon: Layers,
      title: 'Juegos de Mesa',
      description: 'Ruleta, Blackjack, Poker y más',
      image: 'https://images.unsplash.com/photo-1618304925090-b68a8c744cbe?w=800',
      color: 'from-blue-500 to-blue-700',
    },
    {
      icon: Sparkles,
      title: 'Nuevos Juegos',
      description: 'Últimos lanzamientos',
      image: 'https://images.unsplash.com/photo-1582656975064-04e9452fc60e?w=800',
      color: 'from-green-500 to-green-700',
    },
  ];

  return (
    <section className="py-16 lg:py-24 bg-zinc-900">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold text-white mb-4">
            Categorías de Casino
          </h2>
          <p className="text-zinc-400 text-lg max-w-2xl mx-auto">
            Explora nuestra amplia selección de juegos organizados por categorías
          </p>
        </div>

        {/* Categories Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {categories.map((category, index) => {
            const Icon = category.icon;
            return (
              <div
                key={index}
                className="group relative bg-zinc-800 rounded-2xl overflow-hidden border border-zinc-700 hover:border-yellow-500/50 transition-all duration-300 hover:transform hover:scale-105"
              >
                {/* Background Image */}
                <div className="absolute inset-0">
                  <img
                    src={category.image}
                    alt={category.title}
                    className="w-full h-full object-cover opacity-20 group-hover:opacity-30 transition-opacity"
                  />
                  <div className={`absolute inset-0 bg-gradient-to-br ${category.color} opacity-60`}></div>
                </div>

                {/* Content */}
                <div className="relative p-6 lg:p-8">
                  <div className="flex items-start justify-between mb-4">
                    <div className="bg-white/10 backdrop-blur-sm rounded-xl p-3">
                      <Icon className="w-8 h-8 text-white" />
                    </div>
                    <ChevronRight className="w-6 h-6 text-white/60 group-hover:text-white group-hover:translate-x-1 transition-all" />
                  </div>
                  
                  <h3 className="text-2xl font-bold text-white mb-2">
                    {category.title}
                  </h3>
                  <p className="text-white/80 mb-6">
                    {category.description}
                  </p>

                  <Button
                    onClick={() => handleCategoryClick(category.title)}
                    variant="secondary"
                    className="bg-white/20 hover:bg-white/30 text-white border-0 backdrop-blur-sm"
                  >
                    Explorar
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}