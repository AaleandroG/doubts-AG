import { useState, useEffect } from 'react';
import { X, Gift, Sparkles } from 'lucide-react';
import { Button } from './ui/button';

interface PromoBannerProps {
  onRegisterClick: () => void;
}

export function PromoBanner({ onRegisterClick }: PromoBannerProps) {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Show banner after 5 seconds if not dismissed
    const timer = setTimeout(() => {
      const dismissed = sessionStorage.getItem('promoBannerDismissed');
      if (!dismissed) {
        setIsVisible(true);
      }
    }, 5000);

    return () => clearTimeout(timer);
  }, []);

  const handleDismiss = () => {
    setIsVisible(false);
    sessionStorage.setItem('promoBannerDismissed', 'true');
  };

  const handleClaim = () => {
    handleDismiss();
    onRegisterClick();
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className="fixed top-24 right-4 z-40 animate-in slide-in-from-right max-w-sm hidden lg:block">
      <div className="bg-gradient-to-r from-yellow-500 to-orange-500 rounded-2xl p-1 shadow-2xl">
        <div className="bg-zinc-900 rounded-xl p-6 relative">
          <button
            onClick={handleDismiss}
            className="absolute top-3 right-3 text-zinc-400 hover:text-white transition-colors"
            aria-label="Cerrar"
          >
            <X className="w-4 h-4" />
          </button>

          <div className="flex items-start gap-3 mb-4">
            <div className="bg-gradient-to-r from-yellow-500 to-orange-500 rounded-full p-2">
              <Gift className="w-6 h-6 text-black" />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <Sparkles className="w-4 h-4 text-yellow-400" />
                <span className="text-xs text-yellow-400 font-semibold uppercase">
                  Oferta limitada
                </span>
              </div>
              <h4 className="text-white font-bold mb-1">
                ¡Bono de Bienvenida!
              </h4>
              <p className="text-sm text-zinc-300">
                100% hasta 500€ + 100 tiradas gratis
              </p>
            </div>
          </div>

          <Button
            onClick={handleClaim}
            className="w-full bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-black font-bold"
          >
            Reclamar Ahora
          </Button>

          <p className="text-xs text-zinc-500 text-center mt-3">
            Solo para nuevos jugadores. T&C aplicables.
          </p>
        </div>
      </div>
    </div>
  );
}