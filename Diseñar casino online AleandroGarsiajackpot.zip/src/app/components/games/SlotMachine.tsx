import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../ui/dialog';
import { Button } from '../ui/button';
import { Coins, X, TrendingUp, Info } from 'lucide-react';
import { useUser } from '../../contexts/UserContext';
import { toast } from 'sonner';

interface SlotMachineProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  gameName: string;
}

const SYMBOLS = ['🍒', '🍋', '🍊', '🍇', '💎', '⭐', '🔔', '7️⃣'];
const BET_AMOUNTS = [10, 25, 50, 100, 250];

export function SlotMachine({ open, onOpenChange, gameName }: SlotMachineProps) {
  const { user, updateBalance } = useUser();
  const [reels, setReels] = useState(['🍒', '🍒', '🍒']);
  const [isSpinning, setIsSpinning] = useState(false);
  const [betAmount, setBetAmount] = useState(25);
  const [lastWin, setLastWin] = useState(0);

  const spin = () => {
    if (!user) {
      return;
    }

    if (user.balance < betAmount) {
      toast.error('Fichas insuficientes', {
        description: 'Vuelve mañana para recibir 1000 fichas nuevas',
      });
      return;
    }

    setIsSpinning(true);
    setLastWin(0);
    updateBalance(-betAmount); // Descontar apuesta

    // Animación de giro
    let spinCount = 0;
    const spinInterval = setInterval(() => {
      setReels([
        SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)],
        SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)],
        SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)],
      ]);
      spinCount++;

      if (spinCount > 20) {
        clearInterval(spinInterval);
        // Resultado final
        const finalReels = [
          SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)],
          SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)],
          SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)],
        ];
        setReels(finalReels);
        checkWin(finalReels);
        setIsSpinning(false);
      }
    }, 100);
  };

  const checkWin = (finalReels: string[]) => {
    // Tres iguales
    if (finalReels[0] === finalReels[1] && finalReels[1] === finalReels[2]) {
      const multipliers: { [key: string]: number } = {
        '7️⃣': 50,
        '💎': 30,
        '⭐': 20,
        '🔔': 15,
        '🍇': 10,
        '🍊': 8,
        '🍋': 6,
        '🍒': 5,
      };
      const multiplier = multipliers[finalReels[0]] || 5;
      const winAmount = betAmount * multiplier;
      setLastWin(winAmount);
      updateBalance(winAmount);
      
      toast.success('¡GANASTE!', {
        description: `+${winAmount} Fichas Jackpot (${multiplier}x)`,
      });
    }
    // Dos iguales
    else if (
      finalReels[0] === finalReels[1] ||
      finalReels[1] === finalReels[2] ||
      finalReels[0] === finalReels[2]
    ) {
      const winAmount = betAmount * 2;
      setLastWin(winAmount);
      updateBalance(winAmount);
      
      toast.success('¡Premio menor!', {
        description: `+${winAmount} Fichas Jackpot (2x)`,
      });
    } else {
      toast.error('No hay suerte esta vez', {
        description: `Perdiste ${betAmount} fichas`,
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl bg-gradient-to-b from-zinc-900 to-zinc-950 border-zinc-800">
        <DialogHeader>
          <DialogTitle className="text-2xl text-white flex items-center justify-between">
            <span>{gameName}</span>
            <button
              onClick={() => onOpenChange(false)}
              className="text-zinc-400 hover:text-white"
            >
              <X className="w-6 h-6" />
            </button>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Slot Machine Display */}
          <div className="bg-gradient-to-b from-yellow-600/20 to-yellow-800/20 rounded-2xl p-8 border-4 border-yellow-600/50">
            <div className="grid grid-cols-3 gap-4 mb-6">
              {reels.map((symbol, index) => (
                <div
                  key={index}
                  className={`bg-white rounded-xl aspect-square flex items-center justify-center text-6xl shadow-xl ${
                    isSpinning ? 'animate-pulse' : ''
                  }`}
                >
                  {symbol}
                </div>
              ))}
            </div>

            {/* Balance y última ganancia */}
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div className="bg-zinc-900/80 rounded-lg p-3 text-center">
                <p className="text-xs text-zinc-400 mb-1">Tu Balance</p>
                <div className="flex items-center justify-center gap-2">
                  <Coins className="w-4 h-4 text-yellow-500" />
                  <p className="text-lg font-bold text-white">
                    {user?.balance.toLocaleString() || 0}
                  </p>
                </div>
              </div>
              <div className="bg-zinc-900/80 rounded-lg p-3 text-center">
                <p className="text-xs text-zinc-400 mb-1">Última Ganancia</p>
                <div className="flex items-center justify-center gap-2">
                  <TrendingUp className="w-4 h-4 text-green-500" />
                  <p className="text-lg font-bold text-green-500">
                    {lastWin > 0 ? `+${lastWin.toLocaleString()}` : '0'}
                  </p>
                </div>
              </div>
            </div>

            {/* Bet Selection */}
            <div className="bg-zinc-900/80 rounded-lg p-4">
              <p className="text-sm text-zinc-400 mb-3 text-center">Selecciona tu apuesta</p>
              <div className="flex gap-2 justify-center flex-wrap">
                {BET_AMOUNTS.map((amount) => (
                  <button
                    key={amount}
                    onClick={() => setBetAmount(amount)}
                    disabled={isSpinning}
                    className={`px-4 py-2 rounded-lg font-semibold transition-all ${
                      betAmount === amount
                        ? 'bg-yellow-500 text-black'
                        : 'bg-zinc-800 text-zinc-300 hover:bg-zinc-700'
                    }`}
                  >
                    {amount}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Spin Button */}
          <Button
            onClick={spin}
            disabled={isSpinning || !user || user.balance < betAmount}
            className="w-full bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-black font-bold text-xl py-8 disabled:opacity-50"
          >
            {isSpinning ? 'GIRANDO...' : `GIRAR (${betAmount} fichas)`}
          </Button>

          {/* Paytable */}
          <div className="bg-zinc-800/50 rounded-lg p-4">
            <div className="flex items-center gap-2 mb-3">
              <Info className="w-4 h-4 text-yellow-500" />
              <h4 className="text-sm font-semibold text-white">Tabla de Pagos</h4>
            </div>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="flex justify-between text-zinc-400">
                <span>7️⃣ 7️⃣ 7️⃣</span>
                <span className="text-yellow-500 font-semibold">50x</span>
              </div>
              <div className="flex justify-between text-zinc-400">
                <span>💎 💎 💎</span>
                <span className="text-yellow-500 font-semibold">30x</span>
              </div>
              <div className="flex justify-between text-zinc-400">
                <span>⭐ ⭐ ⭐</span>
                <span className="text-yellow-500 font-semibold">20x</span>
              </div>
              <div className="flex justify-between text-zinc-400">
                <span>🔔 🔔 🔔</span>
                <span className="text-yellow-500 font-semibold">15x</span>
              </div>
              <div className="flex justify-between text-zinc-400">
                <span>Dos iguales</span>
                <span className="text-green-500 font-semibold">2x</span>
              </div>
              <div className="flex justify-between text-zinc-400">
                <span>Otras combos</span>
                <span className="text-yellow-500 font-semibold">5-10x</span>
              </div>
            </div>
          </div>

          <p className="text-xs text-center text-zinc-500">
            💰 Moneda virtual sin valor real. Juega responsablemente.
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}