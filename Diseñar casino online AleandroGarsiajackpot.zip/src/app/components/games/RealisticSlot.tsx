import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../ui/dialog';
import { Button } from '../ui/button';
import { Coins, X, TrendingUp, Volume2, VolumeX, Settings } from 'lucide-react';
import { useUser } from '../../contexts/UserContext';
import { toast } from 'sonner';
import { TemuAd } from '../TemuAd';
import { useState, useRef, useEffect } from 'react';

interface RealisticSlotProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  gameName: string;
  theme?: 'classic' | 'diamond' | 'golden' | 'fruit';
}

const SLOT_THEMES = {
  classic: {
    symbols: ['7', 'BAR', '★', '♦', '♣', '♥', '♠', 'WILD'],
    colors: ['#ff0000', '#ffd700', '#00ff00', '#ff69b4', '#4169e1', '#ff4500', '#8a2be2', '#ff1493'],
    bg: 'from-red-900 to-red-950',
  },
  diamond: {
    symbols: ['💎', '👑', '💰', '🏆', '⭐', '🔱', '💸', 'WILD'],
    colors: ['#00d4ff', '#ff00ff', '#ffd700', '#ff6b6b', '#4ecdc4', '#ffe66d', '#a8e6cf', '#ff8b94'],
    bg: 'from-blue-900 to-purple-950',
  },
  golden: {
    symbols: ['🌟', '💫', '✨', '🎰', '🎲', '🃏', '🎯', 'WILD'],
    colors: ['#ffd700', '#ffed4e', '#ffa500', '#ff8c00', '#ffb347', '#ffd700', '#ffe135', '#ffef00'],
    bg: 'from-yellow-900 to-orange-950',
  },
  fruit: {
    symbols: ['🍒', '🍋', '🍊', '🍇', '🍉', '🍓', '🍎', 'WILD'],
    colors: ['#ff0000', '#ffff00', '#ff8c00', '#8b008b', '#00ff00', '#ff1493', '#dc143c', '#32cd32'],
    bg: 'from-green-900 to-green-950',
  },
};

const BET_AMOUNTS = [10, 25, 50, 100, 250, 500, 1000];
const PAYLINES = [1, 3, 5, 9, 15, 20, 25];

export function RealisticSlot({ open, onOpenChange, gameName, theme = 'classic' }: RealisticSlotProps) {
  const { user, updateBalance } = useUser();
  const [reels, setReels] = useState<number[][]>([
    [0, 1, 2],
    [1, 2, 3],
    [2, 3, 4],
    [3, 4, 5],
    [4, 5, 6],
  ]);
  const [isSpinning, setIsSpinning] = useState(false);
  const [betAmount, setBetAmount] = useState(50);
  const [activePaylinesCount, setActivePaylinesCount] = useState(9);
  const [lastWin, setLastWin] = useState(0);
  const [totalWins, setTotalWins] = useState(0);
  const [spinCount, setSpinCount] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [autoSpin, setAutoSpin] = useState(false);
  const [autoSpinCount, setAutoSpinCount] = useState(0);
  
  const slotTheme = SLOT_THEMES[theme];
  const canvasRefs = useRef<(HTMLCanvasElement | null)[]>([]);

  // Dibujar símbolos en canvas
  useEffect(() => {
    canvasRefs.current.forEach((canvas, reelIndex) => {
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      const height = canvas.height;
      const symbolHeight = height / 3;

      reels[reelIndex].forEach((symbolIndex, position) => {
        const y = position * symbolHeight;
        const symbol = slotTheme.symbols[symbolIndex];
        const color = slotTheme.colors[symbolIndex];

        // Fondo del símbolo
        ctx.fillStyle = '#1a1a1a';
        ctx.fillRect(0, y, canvas.width, symbolHeight);

        // Borde
        ctx.strokeStyle = '#333';
        ctx.lineWidth = 2;
        ctx.strokeRect(2, y + 2, canvas.width - 4, symbolHeight - 4);

        // Símbolo
        if (symbol === 'WILD' || symbol === 'BAR' || symbol === '7') {
          ctx.fillStyle = color;
          ctx.font = 'bold 32px Arial';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText(symbol, canvas.width / 2, y + symbolHeight / 2);
        } else {
          ctx.font = '48px Arial';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText(symbol, canvas.width / 2, y + symbolHeight / 2);
        }

        // Efecto de brillo si está girando
        if (isSpinning) {
          const gradient = ctx.createLinearGradient(0, y, 0, y + symbolHeight);
          gradient.addColorStop(0, 'rgba(255,255,255,0.3)');
          gradient.addColorStop(0.5, 'rgba(255,255,255,0)');
          gradient.addColorStop(1, 'rgba(0,0,0,0.3)');
          ctx.fillStyle = gradient;
          ctx.fillRect(0, y, canvas.width, symbolHeight);
        }
      });
    });
  }, [reels, isSpinning, slotTheme]);

  const spin = async () => {
    if (!user) {
      return;
    }

    if (user.balance < betAmount) {
      toast.error('Fichas insuficientes', {
        description: 'Vuelve mañana para recibir 1000 fichas nuevas',
      });
      return;
    }

    setIsSpinning(true);
    setLastWin(0);
    updateBalance(-betAmount);
    setSpinCount(spinCount + 1);

    // Animación de giro - cada reel para en diferente momento
    const newReels: number[][] = [];
    for (let i = 0; i < 5; i++) {
      await new Promise(resolve => setTimeout(resolve, i * 150));
      
      // Simular giro con animación
      let spinIterations = 0;
      const spinInterval = setInterval(() => {
        setReels(prev => {
          const updated = [...prev];
          updated[i] = [
            Math.floor(Math.random() * slotTheme.symbols.length),
            Math.floor(Math.random() * slotTheme.symbols.length),
            Math.floor(Math.random() * slotTheme.symbols.length),
          ];
          return updated;
        });
        spinIterations++;
        
        if (spinIterations > 10 + i * 3) {
          clearInterval(spinInterval);
          // Resultado final
          const finalReel = [
            Math.floor(Math.random() * slotTheme.symbols.length),
            Math.floor(Math.random() * slotTheme.symbols.length),
            Math.floor(Math.random() * slotTheme.symbols.length),
          ];
          newReels[i] = finalReel;
          
          setReels(prev => {
            const updated = [...prev];
            updated[i] = finalReel;
            return updated;
          });
        }
      }, 50);
    }

    // Esperar a que todos los reels terminen
    setTimeout(() => {
      checkWin(newReels);
      setIsSpinning(false);
      
      if (autoSpin && autoSpinCount > 1) {
        setAutoSpinCount(autoSpinCount - 1);
        setTimeout(() => spin(), 1000);
      } else if (autoSpin && autoSpinCount <= 1) {
        setAutoSpin(false);
        setAutoSpinCount(0);
      }
    }, 2000);
  };

  const checkWin = (finalReels: number[][]) => {
    let totalWinAmount = 0;

    // Verificar líneas de pago (simplificado - línea del medio)
    const middleLine = finalReels.map(reel => reel[1]);
    
    // Tres iguales consecutivos
    for (let i = 0; i <= middleLine.length - 3; i++) {
      if (middleLine[i] === middleLine[i + 1] && middleLine[i + 1] === middleLine[i + 2]) {
        const symbol = middleLine[i];
        let multiplier = 5;
        
        // Wilds y símbolos especiales
        if (slotTheme.symbols[symbol] === 'WILD') multiplier = 50;
        else if (slotTheme.symbols[symbol] === '7') multiplier = 30;
        else if (slotTheme.symbols[symbol] === 'BAR') multiplier = 20;
        else if (symbol === 0) multiplier = 15; // Primer símbolo
        
        // 4 iguales
        if (i <= middleLine.length - 4 && middleLine[i] === middleLine[i + 3]) {
          multiplier *= 2;
        }
        
        // 5 iguales
        if (middleLine.every(s => s === middleLine[0])) {
          multiplier *= 5;
        }
        
        totalWinAmount += betAmount * multiplier;
      }
    }

    // Verificar líneas adicionales según activePaylinesCount
    if (activePaylinesCount >= 5) {
      // Línea superior
      const topLine = finalReels.map(reel => reel[0]);
      if (topLine[0] === topLine[1] && topLine[1] === topLine[2]) {
        totalWinAmount += betAmount * 3;
      }
      
      // Línea inferior
      const bottomLine = finalReels.map(reel => reel[2]);
      if (bottomLine[0] === bottomLine[1] && bottomLine[1] === bottomLine[2]) {
        totalWinAmount += betAmount * 3;
      }
    }

    if (totalWinAmount > 0) {
      setLastWin(totalWinAmount);
      setTotalWins(totalWins + totalWinAmount);
      updateBalance(totalWinAmount);
      
      const multiplier = Math.floor(totalWinAmount / betAmount);
      toast.success('¡GANASTE!', {
        description: `+${totalWinAmount} Fichas (${multiplier}x)`,
      });
    }
  };

  const startAutoSpin = (count: number) => {
    setAutoSpin(true);
    setAutoSpinCount(count);
    spin();
  };

  const totalBet = betAmount * activePaylinesCount;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-6xl bg-gradient-to-b from-zinc-900 to-zinc-950 border-zinc-800 max-h-[95vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl text-white flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span>{gameName}</span>
              <span className="text-sm font-normal text-zinc-400">
                ({activePaylinesCount} líneas)
              </span>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsMuted(!isMuted)}
                className="text-zinc-400 hover:text-white p-2"
              >
                {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
              </button>
              <button
                onClick={() => onOpenChange(false)}
                className="text-zinc-400 hover:text-white"
              >
                <X className="w-6 h-6" />
              </button>
            </div>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Stats Bar */}
          <div className="grid grid-cols-4 gap-3">
            <div className="bg-zinc-800/80 rounded-lg p-3 text-center">
              <p className="text-xs text-zinc-400 mb-1">Balance</p>
              <div className="flex items-center justify-center gap-1">
                <Coins className="w-4 h-4 text-yellow-500" />
                <p className="text-lg font-bold text-white">
                  {user?.balance.toLocaleString() || 0}
                </p>
              </div>
            </div>
            <div className="bg-zinc-800/80 rounded-lg p-3 text-center">
              <p className="text-xs text-zinc-400 mb-1">Última Ganancia</p>
              <p className="text-lg font-bold text-green-500">
                {lastWin > 0 ? `+${lastWin}` : '0'}
              </p>
            </div>
            <div className="bg-zinc-800/80 rounded-lg p-3 text-center">
              <p className="text-xs text-zinc-400 mb-1">Total Ganado</p>
              <p className="text-lg font-bold text-yellow-500">
                {totalWins.toLocaleString()}
              </p>
            </div>
            <div className="bg-zinc-800/80 rounded-lg p-3 text-center">
              <p className="text-xs text-zinc-400 mb-1">Giros</p>
              <p className="text-lg font-bold text-blue-500">
                {spinCount}
              </p>
            </div>
          </div>

          {/* Slot Machine */}
          <div className={`bg-gradient-to-b ${slotTheme.bg} rounded-2xl p-8 border-4 border-yellow-600/50 shadow-2xl`}>
            {/* Paylines indicator */}
            <div className="mb-4 flex justify-center gap-1">
              {Array.from({ length: activePaylinesCount }).map((_, i) => (
                <div key={i} className="w-2 h-2 bg-yellow-500 rounded-full animate-pulse" />
              ))}
            </div>

            {/* Reels */}
            <div className="flex gap-2 justify-center mb-4">
              {reels.map((_, index) => (
                <canvas
                  key={index}
                  ref={el => canvasRefs.current[index] = el}
                  width={120}
                  height={360}
                  className="bg-zinc-950 rounded-lg shadow-xl border-2 border-zinc-700"
                />
              ))}
            </div>

            {/* Win Line Indicator */}
            <div className="text-center mb-4">
              {lastWin > 0 && (
                <div className="inline-block bg-yellow-500 text-black px-6 py-2 rounded-full font-bold text-xl animate-bounce">
                  GANASTE {lastWin} FICHAS! 🎉
                </div>
              )}
            </div>
          </div>

          {/* Controls */}
          <div className="bg-zinc-800/50 rounded-xl p-6">
            <div className="grid md:grid-cols-2 gap-6">
              {/* Bet Amount */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <p className="text-sm text-zinc-400">Apuesta por línea</p>
                  <p className="text-sm font-bold text-white">{betAmount} fichas</p>
                </div>
                <div className="flex gap-2 flex-wrap">
                  {BET_AMOUNTS.map((amount) => (
                    <button
                      key={amount}
                      onClick={() => setBetAmount(amount)}
                      disabled={isSpinning}
                      className={`px-4 py-2 rounded-lg font-semibold transition-all ${
                        betAmount === amount
                          ? 'bg-yellow-500 text-black'
                          : 'bg-zinc-700 text-zinc-300 hover:bg-zinc-600'
                      }`}
                    >
                      {amount}
                    </button>
                  ))}
                </div>
              </div>

              {/* Paylines */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <p className="text-sm text-zinc-400">Líneas activas</p>
                  <p className="text-sm font-bold text-white">{activePaylinesCount} líneas</p>
                </div>
                <div className="flex gap-2 flex-wrap">
                  {PAYLINES.map((lines) => (
                    <button
                      key={lines}
                      onClick={() => setActivePaylinesCount(lines)}
                      disabled={isSpinning}
                      className={`px-4 py-2 rounded-lg font-semibold transition-all ${
                        activePaylinesCount === lines
                          ? 'bg-yellow-500 text-black'
                          : 'bg-zinc-700 text-zinc-300 hover:bg-zinc-600'
                      }`}
                    >
                      {lines}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="mt-4 text-center">
              <p className="text-sm text-zinc-400">
                Apuesta total: <span className="text-white font-bold">{totalBet}</span> fichas
              </p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <Button
              onClick={spin}
              disabled={isSpinning || !user || user.balance < totalBet || autoSpin}
              className="bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-black font-bold py-6"
            >
              {isSpinning ? 'GIRANDO...' : 'GIRAR'}
            </Button>
            <Button
              onClick={() => startAutoSpin(10)}
              disabled={isSpinning || !user || user.balance < totalBet || autoSpin}
              variant="outline"
              className="border-yellow-500 text-yellow-500 hover:bg-yellow-500 hover:text-black font-bold py-6"
            >
              AUTO x10
            </Button>
            <Button
              onClick={() => startAutoSpin(25)}
              disabled={isSpinning || !user || user.balance < totalBet || autoSpin}
              variant="outline"
              className="border-yellow-500 text-yellow-500 hover:bg-yellow-500 hover:text-black font-bold py-6"
            >
              AUTO x25
            </Button>
            <Button
              onClick={() => setAutoSpin(false)}
              disabled={!autoSpin}
              variant="destructive"
              className="font-bold py-6"
            >
              DETENER
            </Button>
          </div>

          {autoSpin && (
            <div className="text-center text-yellow-500 font-semibold animate-pulse">
              Auto-spin activo: {autoSpinCount} giros restantes
            </div>
          )}

          <p className="text-xs text-center text-zinc-500">
            💰 Moneda virtual sin valor real. Juega responsablemente.
          </p>

          {/* Anuncio Temu en el juego */}
          <div className="mt-4">
            <TemuAd variant="inline" />
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}