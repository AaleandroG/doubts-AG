import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../ui/dialog';
import { Button } from '../ui/button';
import { Coins, X, Trophy } from 'lucide-react';
import { useUser } from '../../contexts/UserContext';
import { toast } from 'sonner';
import { TemuAd } from '../TemuAd';

interface VideoPokerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  gameName: string;
}

interface Card {
  suit: '♠' | '♥' | '♦' | '♣';
  value: string;
  numValue: number;
}

const SUITS: ('♠' | '♥' | '♦' | '♣')[] = ['♠', '♥', '♦', '♣'];
const VALUES = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A'];
const BET_AMOUNTS = [10, 25, 50, 100, 250];

export function VideoPoker({ open, onOpenChange, gameName }: VideoPokerProps) {
  const { user, updateBalance } = useUser();
  const [hand, setHand] = useState<Card[]>([]);
  const [held, setHeld] = useState<boolean[]>([false, false, false, false, false]);
  const [gameState, setGameState] = useState<'betting' | 'draw' | 'result'>('betting');
  const [betAmount, setBetAmount] = useState(25);
  const [lastWin, setLastWin] = useState(0);
  const [deck, setDeck] = useState<Card[]>([]);

  const createDeck = (): Card[] => {
    const newDeck: Card[] = [];
    for (const suit of SUITS) {
      VALUES.forEach((value, index) => {
        newDeck.push({
          suit,
          value,
          numValue: index + 2,
        });
      });
    }
    return shuffleDeck(newDeck);
  };

  const shuffleDeck = (deck: Card[]): Card[] => {
    const shuffled = [...deck];
    for (let i = shuffled.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
  };

  const dealCards = () => {
    if (!user) {
      return;
    }

    if (user.balance < betAmount) {
      toast.error('Fichas insuficientes', {
        description: 'Vuelve mañana para recibir 1000 fichas nuevas',
      });
      return;
    }

    updateBalance(-betAmount);
    const newDeck = createDeck();
    const initialHand = newDeck.slice(0, 5);
    
    setHand(initialHand);
    setDeck(newDeck.slice(5));
    setHeld([false, false, false, false, false]);
    setGameState('draw');
    setLastWin(0);
  };

  const toggleHold = (index: number) => {
    if (gameState !== 'draw') return;
    const newHeld = [...held];
    newHeld[index] = !newHeld[index];
    setHeld(newHeld);
  };

  const drawCards = () => {
    let newHand = [...hand];
    let currentDeck = [...deck];
    
    held.forEach((isHeld, index) => {
      if (!isHeld) {
        newHand[index] = currentDeck[0];
        currentDeck = currentDeck.slice(1);
      }
    });

    setHand(newHand);
    setDeck(currentDeck);
    
    const result = evaluateHand(newHand);
    setGameState('result');
    
    if (result.payout > 0) {
      const winAmount = betAmount * result.payout;
      setLastWin(winAmount);
      updateBalance(winAmount);
      toast.success(`¡${result.name}!`, {
        description: `+${winAmount} Fichas (${result.payout}x)`,
      });
    } else {
      toast.error('Sin premio', {
        description: 'Intenta de nuevo',
      });
    }
  };

  const evaluateHand = (cards: Card[]): { name: string; payout: number } => {
    const values = cards.map(c => c.numValue).sort((a, b) => a - b);
    const suits = cards.map(c => c.suit);
    const valueCounts = values.reduce((acc, val) => {
      acc[val] = (acc[val] || 0) + 1;
      return acc;
    }, {} as Record<number, number>);
    
    const counts = Object.values(valueCounts).sort((a, b) => b - a);
    const isFlush = suits.every(s => s === suits[0]);
    const isStraight = values.every((v, i) => i === 0 || v === values[i - 1] + 1) ||
      (values[0] === 2 && values[4] === 14 && values[1] === 3 && values[2] === 4 && values[3] === 5);
    
    // Royal Flush
    if (isFlush && isStraight && values[0] === 10) {
      return { name: 'ROYAL FLUSH', payout: 250 };
    }
    
    // Straight Flush
    if (isFlush && isStraight) {
      return { name: 'STRAIGHT FLUSH', payout: 50 };
    }
    
    // Four of a Kind
    if (counts[0] === 4) {
      return { name: 'POKER', payout: 25 };
    }
    
    // Full House
    if (counts[0] === 3 && counts[1] === 2) {
      return { name: 'FULL HOUSE', payout: 9 };
    }
    
    // Flush
    if (isFlush) {
      return { name: 'FLUSH', payout: 6 };
    }
    
    // Straight
    if (isStraight) {
      return { name: 'STRAIGHT', payout: 4 };
    }
    
    // Three of a Kind
    if (counts[0] === 3) {
      return { name: 'TRÍO', payout: 3 };
    }
    
    // Two Pair
    if (counts[0] === 2 && counts[1] === 2) {
      return { name: 'DOS PARES', payout: 2 };
    }
    
    // Pair of Jacks or Better
    const pairValue = Object.entries(valueCounts).find(([_, count]) => count === 2)?.[0];
    if (pairValue && parseInt(pairValue) >= 11) {
      return { name: 'PAR ALTO', payout: 1 };
    }
    
    return { name: 'Nada', payout: 0 };
  };

  const renderCard = (card: Card, index: number) => {
    const isRed = card.suit === '♥' || card.suit === '♦';
    const isHeld = held[index];
    
    return (
      <div className="relative">
        {isHeld && gameState === 'draw' && (
          <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-yellow-500 text-black px-3 py-1 rounded-full text-xs font-bold animate-bounce">
            RETENIDA
          </div>
        )}
        <button
          onClick={() => toggleHold(index)}
          disabled={gameState !== 'draw'}
          className={`w-28 h-40 bg-white rounded-xl shadow-2xl flex flex-col items-center justify-center border-4 transition-all ${
            isHeld
              ? 'border-yellow-500 transform scale-105'
              : 'border-zinc-300 hover:border-yellow-400'
          } ${gameState !== 'draw' ? 'cursor-default' : 'cursor-pointer hover:scale-105'}`}
        >
          <div className={`text-5xl font-bold mb-2 ${isRed ? 'text-red-600' : 'text-black'}`}>
            {card.value}
          </div>
          <div className={`text-4xl ${isRed ? 'text-red-600' : 'text-black'}`}>
            {card.suit}
          </div>
        </button>
      </div>
    );
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-5xl bg-gradient-to-b from-green-900 to-green-950 border-yellow-600 max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl text-white flex items-center justify-between">
            <span>{gameName}</span>
            <button
              onClick={() => onOpenChange(false)}
              className="text-zinc-400 hover:text-white"
            >
              <X className="w-6 h-6" />
            </button>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Stats */}
          <div className="flex items-center justify-between bg-zinc-900/80 rounded-lg p-4">
            <div className="flex items-center gap-2">
              <Coins className="w-5 h-5 text-yellow-500" />
              <div>
                <p className="text-xs text-zinc-400">Balance</p>
                <p className="text-xl font-bold text-white">
                  {user?.balance.toLocaleString() || 0}
                </p>
              </div>
            </div>
            {lastWin > 0 && (
              <div className="flex items-center gap-2">
                <Trophy className="w-5 h-5 text-yellow-500" />
                <div>
                  <p className="text-xs text-zinc-400">Última Ganancia</p>
                  <p className="text-xl font-bold text-yellow-500">
                    +{lastWin}
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Paytable */}
          <div className="bg-zinc-900/80 rounded-xl p-4">
            <h3 className="text-sm font-bold text-white mb-3 text-center">TABLA DE PAGOS</h3>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-2 text-xs">
              {[
                { name: 'Royal Flush', payout: 250 },
                { name: 'Straight Flush', payout: 50 },
                { name: 'Poker', payout: 25 },
                { name: 'Full House', payout: 9 },
                { name: 'Flush', payout: 6 },
                { name: 'Straight', payout: 4 },
                { name: 'Trío', payout: 3 },
                { name: 'Dos Pares', payout: 2 },
                { name: 'Par Alto (J+)', payout: 1 },
              ].map((hand) => (
                <div key={hand.name} className="bg-zinc-800 rounded p-2 text-center">
                  <p className="text-zinc-400">{hand.name}</p>
                  <p className="text-yellow-500 font-bold">{hand.payout}x</p>
                </div>
              ))}
            </div>
          </div>

          {/* Cards */}
          {hand.length > 0 && (
            <div className="flex gap-3 justify-center py-8">
              {hand.map((card, index) => (
                <div key={index}>{renderCard(card, index)}</div>
              ))}
            </div>
          )}

          {/* Bet Selection */}
          {gameState === 'betting' && (
            <div className="bg-zinc-900/80 rounded-xl p-6">
              <p className="text-sm text-zinc-400 mb-3 text-center">Selecciona tu apuesta</p>
              <div className="flex gap-3 justify-center flex-wrap">
                {BET_AMOUNTS.map((amount) => (
                  <button
                    key={amount}
                    onClick={() => setBetAmount(amount)}
                    className={`px-6 py-3 rounded-lg font-semibold transition-all ${
                      betAmount === amount
                        ? 'bg-yellow-500 text-black'
                        : 'bg-zinc-700 text-zinc-300 hover:bg-zinc-600'
                    }`}
                  >
                    {amount}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Instructions */}
          {gameState === 'draw' && (
            <div className="text-center">
              <p className="text-yellow-400 font-semibold animate-pulse">
                👆 Haz clic en las cartas que quieres retener
              </p>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex gap-3">
            {gameState === 'betting' && (
              <Button
                onClick={dealCards}
                disabled={!user || user.balance < betAmount}
                className="flex-1 bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-black font-bold text-lg py-6"
              >
                REPARTIR ({betAmount} fichas)
              </Button>
            )}
            
            {gameState === 'draw' && (
              <Button
                onClick={drawCards}
                className="flex-1 bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-black font-bold text-lg py-6"
              >
                CAMBIAR CARTAS
              </Button>
            )}
            
            {gameState === 'result' && (
              <Button
                onClick={() => {
                  setGameState('betting');
                  setHand([]);
                  setHeld([false, false, false, false, false]);
                }}
                className="flex-1 bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-black font-bold text-lg py-6"
              >
                NUEVA PARTIDA
              </Button>
            )}
          </div>

          <p className="text-xs text-center text-zinc-300">
            💰 Moneda virtual sin valor real. Juega responsablemente.
          </p>

          {/* Anuncio Temu */}
          <div className="mt-4">
            <TemuAd variant="inline" />
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}