import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../ui/dialog';
import { Button } from '../ui/button';
import { Coins, X, PlayCircle } from 'lucide-react';
import { useUser } from '../../contexts/UserContext';
import { toast } from 'sonner';
import { TemuAd } from '../TemuAd';

interface RouletteProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  gameName: string;
}

const NUMBERS = Array.from({ length: 37 }, (_, i) => i); // 0-36
const RED = [1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36];
const BLACK = [2, 4, 6, 8, 10, 11, 13, 15, 17, 20, 22, 24, 26, 28, 29, 31, 33, 35];

export function Roulette({ open, onOpenChange, gameName }: RouletteProps) {
  const { user, updateBalance } = useUser();
  const [spinning, setSpinning] = useState(false);
  const [result, setResult] = useState<number | null>(null);
  const [bets, setBets] = useState<{ type: string; amount: number }[]>([]);
  const [betAmount, setBetAmount] = useState(25);
  const [rotation, setRotation] = useState(0);

  const BET_TYPES = [
    { label: 'Rojo', type: 'red', payout: 2 },
    { label: 'Negro', type: 'black', payout: 2 },
    { label: 'Par', type: 'even', payout: 2 },
    { label: 'Impar', type: 'odd', payout: 2 },
    { label: '1-18', type: 'low', payout: 2 },
    { label: '19-36', type: 'high', payout: 2 },
  ];

  const placeBet = (type: string) => {
    if (!user) {
      return;
    }

    const totalBets = bets.reduce((sum, bet) => sum + bet.amount, 0);
    if (user.balance < totalBets + betAmount) {
      toast.error('Fichas insuficientes');
      return;
    }

    setBets([...bets, { type, amount: betAmount }]);
    toast.success('Apuesta colocada', {
      description: `${betAmount} fichas en ${type}`,
    });
  };

  const spin = () => {
    if (bets.length === 0) {
      toast.error('Debes hacer al menos una apuesta');
      return;
    }

    const totalBet = bets.reduce((sum, bet) => sum + bet.amount, 0);
    if (user!.balance < totalBet) {
      toast.error('Fichas insuficientes');
      return;
    }

    setSpinning(true);
    updateBalance(-totalBet);

    // Animación de giro
    const spins = 5 + Math.random() * 3;
    const finalRotation = rotation + spins * 360 + Math.random() * 360;
    setRotation(finalRotation);

    setTimeout(() => {
      const winningNumber = Math.floor(Math.random() * 37);
      setResult(winningNumber);
      checkWins(winningNumber);
      setSpinning(false);
      setBets([]);
    }, 3000);
  };

  const checkWins = (number: number) => {
    let totalWin = 0;

    bets.forEach((bet) => {
      let isWin = false;
      let payout = 2;

      switch (bet.type) {
        case 'red':
          isWin = RED.includes(number);
          break;
        case 'black':
          isWin = BLACK.includes(number);
          break;
        case 'even':
          isWin = number !== 0 && number % 2 === 0;
          break;
        case 'odd':
          isWin = number % 2 === 1;
          break;
        case 'low':
          isWin = number >= 1 && number <= 18;
          break;
        case 'high':
          isWin = number >= 19 && number <= 36;
          break;
      }

      if (isWin) {
        totalWin += bet.amount * payout;
      }
    });

    if (totalWin > 0) {
      updateBalance(totalWin);
      toast.success(`¡GANASTE!`, {
        description: `+${totalWin} Fichas Jackpot`,
      });
    } else {
      toast.error('No hubo suerte', {
        description: `Número ganador: ${number}`,
      });
    }
  };

  const clearBets = () => {
    setBets([]);
    toast.info('Apuestas eliminadas');
  };

  const getNumberColor = (num: number) => {
    if (num === 0) return 'bg-green-600';
    if (RED.includes(num)) return 'bg-red-600';
    return 'bg-zinc-900';
  };

  const totalBetAmount = bets.reduce((sum, bet) => sum + bet.amount, 0);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-4xl bg-gradient-to-b from-zinc-900 to-zinc-950 border-zinc-800 max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl text-white flex items-center justify-between">
            <span>{gameName}</span>
            <button
              onClick={() => onOpenChange(false)}
              className="text-zinc-400 hover:text-white"
            >
              <X className="w-6 h-6" />
            </button>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Roulette Wheel */}
          <div className="flex flex-col items-center">
            <div className="relative w-64 h-64 mb-4">
              <div
                className={`w-full h-full rounded-full border-8 border-yellow-600 bg-gradient-to-br from-zinc-800 to-zinc-900 flex items-center justify-center transition-transform duration-3000 ease-out ${
                  spinning ? 'animate-spin' : ''
                }`}
                style={{ transform: `rotate(${rotation}deg)` }}
              >
                <div className="text-center">
                  <PlayCircle className="w-12 h-12 text-yellow-500 mx-auto mb-2" />
                  {result !== null && !spinning && (
                    <div className="text-5xl font-bold text-white">{result}</div>
                  )}
                </div>
              </div>
              {/* Pointer */}
              <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-2">
                <div className="w-0 h-0 border-l-8 border-r-8 border-t-12 border-l-transparent border-r-transparent border-t-yellow-500"></div>
              </div>
            </div>

            {result !== null && !spinning && (
              <div
                className={`${getNumberColor(
                  result
                )} text-white px-6 py-3 rounded-lg font-bold text-xl`}
              >
                {result} - {RED.includes(result) ? 'Rojo' : BLACK.includes(result) ? 'Negro' : 'Verde'}
              </div>
            )}
          </div>

          {/* Betting Area */}
          <div className="bg-zinc-800/50 rounded-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-sm text-zinc-400">Balance</p>
                <div className="flex items-center gap-2">
                  <Coins className="w-5 h-5 text-yellow-500" />
                  <p className="text-xl font-bold text-white">
                    {user?.balance.toLocaleString() || 0}
                  </p>
                </div>
              </div>
              <div>
                <p className="text-sm text-zinc-400">Apostado</p>
                <p className="text-xl font-bold text-red-500">
                  {totalBetAmount.toLocaleString()}
                </p>
              </div>
            </div>

            {/* Bet Amount Selector */}
            <div className="mb-4">
              <p className="text-sm text-zinc-400 mb-2">Monto de apuesta</p>
              <div className="flex gap-2 flex-wrap">
                {[10, 25, 50, 100, 250].map((amount) => (
                  <button
                    key={amount}
                    onClick={() => setBetAmount(amount)}
                    disabled={spinning}
                    className={`px-4 py-2 rounded-lg font-semibold transition-all ${
                      betAmount === amount
                        ? 'bg-yellow-500 text-black'
                        : 'bg-zinc-700 text-zinc-300 hover:bg-zinc-600'
                    }`}
                  >
                    {amount}
                  </button>
                ))}
              </div>
            </div>

            {/* Bet Types */}
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {BET_TYPES.map((betType) => (
                <button
                  key={betType.type}
                  onClick={() => placeBet(betType.type)}
                  disabled={spinning}
                  className="bg-zinc-700 hover:bg-zinc-600 text-white font-semibold py-3 px-4 rounded-lg transition-all disabled:opacity-50"
                >
                  {betType.label}
                  <span className="block text-xs text-zinc-400">{betType.payout}x</span>
                </button>
              ))}
            </div>

            {/* Current Bets */}
            {bets.length > 0 && (
              <div className="mt-4 bg-zinc-900/50 rounded-lg p-3">
                <p className="text-xs text-zinc-400 mb-2">Tus apuestas:</p>
                <div className="flex flex-wrap gap-2">
                  {bets.map((bet, index) => (
                    <span
                      key={index}
                      className="text-xs bg-yellow-500/20 text-yellow-400 px-2 py-1 rounded"
                    >
                      {bet.type}: {bet.amount}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3">
            <Button
              onClick={spin}
              disabled={spinning || bets.length === 0}
              className="flex-1 bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-black font-bold text-lg py-6"
            >
              {spinning ? 'GIRANDO...' : 'GIRAR RULETA'}
            </Button>
            <Button
              onClick={clearBets}
              disabled={spinning || bets.length === 0}
              variant="outline"
              className="border-zinc-700 text-white hover:bg-zinc-800"
            >
              Limpiar
            </Button>
          </div>

          <p className="text-xs text-center text-zinc-500">
            💰 Moneda virtual sin valor real. Juega responsablemente.
          </p>

          {/* Anuncio Temu */}
          <div className="mt-4">
            <TemuAd variant="inline" />
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}