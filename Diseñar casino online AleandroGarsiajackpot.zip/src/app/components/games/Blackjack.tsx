import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../ui/dialog';
import { Button } from '../ui/button';
import { Coins, X, PlayCircle, Hand, UserCircle } from 'lucide-react';
import { useUser } from '../../contexts/UserContext';
import { toast } from 'sonner';
import { TemuAd } from '../TemuAd';

interface BlackjackProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  gameName: string;
}

interface Card {
  suit: string;
  value: string;
  numValue: number;
}

const SUITS = ['♠', '♥', '♦', '♣'];
const VALUES = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];

export function Blackjack({ open, onOpenChange, gameName }: BlackjackProps) {
  const { user, updateBalance } = useUser();
  const [gameState, setGameState] = useState<'betting' | 'playing' | 'dealer' | 'finished'>('betting');
  const [playerHand, setPlayerHand] = useState<Card[]>([]);
  const [dealerHand, setDealerHand] = useState<Card[]>([]);
  const [betAmount, setBetAmount] = useState(50);
  const [deck, setDeck] = useState<Card[]>([]);

  const createDeck = (): Card[] => {
    const newDeck: Card[] = [];
    for (const suit of SUITS) {
      for (const value of VALUES) {
        let numValue = parseInt(value);
        if (value === 'A') numValue = 11;
        else if (['J', 'Q', 'K'].includes(value)) numValue = 10;
        newDeck.push({ suit, value, numValue });
      }
    }
    return shuffleDeck(newDeck);
  };

  const shuffleDeck = (deck: Card[]): Card[] => {
    const shuffled = [...deck];
    for (let i = shuffled.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
  };

  const calculateHandValue = (hand: Card[]): number => {
    let value = hand.reduce((sum, card) => sum + card.numValue, 0);
    let aces = hand.filter((card) => card.value === 'A').length;

    while (value > 21 && aces > 0) {
      value -= 10;
      aces--;
    }

    return value;
  };

  const startGame = () => {
    if (!user) {
      return;
    }

    if (user.balance < betAmount) {
      toast.error('Fichas insuficientes', {
        description: 'Vuelve mañana para recibir 1000 fichas nuevas',
      });
      return;
    }

    updateBalance(-betAmount);
    const newDeck = createDeck();
    const player = [newDeck[0], newDeck[2]];
    const dealer = [newDeck[1], newDeck[3]];

    setDeck(newDeck.slice(4));
    setPlayerHand(player);
    setDealerHand(dealer);
    setGameState('playing');

    // Check for natural blackjack
    if (calculateHandValue(player) === 21) {
      setTimeout(() => finishGame(player, dealer, newDeck.slice(4)), 500);
    }
  };

  const hit = () => {
    const newCard = deck[0];
    const newHand = [...playerHand, newCard];
    setPlayerHand(newHand);
    setDeck(deck.slice(1));

    const handValue = calculateHandValue(newHand);
    if (handValue > 21) {
      // Bust
      setTimeout(() => {
        toast.error('¡Te pasaste!', {
          description: `Tu mano: ${handValue}`,
        });
        setGameState('finished');
      }, 500);
    } else if (handValue === 21) {
      stand(newHand);
    }
  };

  const stand = (hand = playerHand) => {
    setGameState('dealer');
    let currentDeck = [...deck];
    let currentDealerHand = [...dealerHand];

    // Dealer draws until 17 or higher
    setTimeout(() => {
      const dealerInterval = setInterval(() => {
        const dealerValue = calculateHandValue(currentDealerHand);
        if (dealerValue < 17) {
          const newCard = currentDeck[0];
          currentDealerHand = [...currentDealerHand, newCard];
          currentDeck = currentDeck.slice(1);
          setDealerHand(currentDealerHand);
        } else {
          clearInterval(dealerInterval);
          finishGame(hand, currentDealerHand, currentDeck);
        }
      }, 1000);
    }, 500);
  };

  const finishGame = (playerFinal: Card[], dealerFinal: Card[], finalDeck: Card[]) => {
    const playerValue = calculateHandValue(playerFinal);
    const dealerValue = calculateHandValue(dealerFinal);

    setGameState('finished');

    if (playerValue > 21) {
      toast.error('Perdiste', {
        description: `Te pasaste con ${playerValue}`,
      });
    } else if (dealerValue > 21) {
      const winAmount = betAmount * 2;
      updateBalance(winAmount);
      toast.success('¡GANASTE!', {
        description: `El dealer se pasó. +${winAmount} fichas`,
      });
    } else if (playerValue > dealerValue) {
      const winAmount = betAmount * 2;
      updateBalance(winAmount);
      toast.success('¡GANASTE!', {
        description: `${playerValue} vs ${dealerValue}. +${winAmount} fichas`,
      });
    } else if (playerValue === dealerValue) {
      updateBalance(betAmount);
      toast.info('Empate', {
        description: `Ambos tienen ${playerValue}. Recuperas tu apuesta`,
      });
    } else {
      toast.error('Perdiste', {
        description: `${playerValue} vs ${dealerValue}`,
      });
    }
  };

  const reset = () => {
    setGameState('betting');
    setPlayerHand([]);
    setDealerHand([]);
    setDeck([]);
  };

  const renderCard = (card: Card, hidden = false) => {
    const isRed = card.suit === '♥' || card.suit === '♦';
    return (
      <div
        className={`w-20 h-28 bg-white rounded-lg shadow-xl flex flex-col items-center justify-center border-2 ${
          hidden ? 'bg-gradient-to-br from-blue-600 to-blue-800' : 'border-zinc-300'
        }`}
      >
        {hidden ? (
          <div className="text-4xl">🂠</div>
        ) : (
          <>
            <div className={`text-3xl font-bold ${isRed ? 'text-red-600' : 'text-black'}`}>
              {card.value}
            </div>
            <div className={`text-2xl ${isRed ? 'text-red-600' : 'text-black'}`}>
              {card.suit}
            </div>
          </>
        )}
      </div>
    );
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-4xl bg-gradient-to-b from-green-900 to-green-950 border-yellow-600 max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl text-white flex items-center justify-between">
            <span>{gameName}</span>
            <button
              onClick={() => onOpenChange(false)}
              className="text-zinc-400 hover:text-white"
            >
              <X className="w-6 h-6" />
            </button>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Balance */}
          <div className="flex items-center justify-between bg-zinc-900/50 rounded-lg p-4">
            <div className="flex items-center gap-2">
              <Coins className="w-5 h-5 text-yellow-500" />
              <div>
                <p className="text-xs text-zinc-400">Balance</p>
                <p className="text-xl font-bold text-white">
                  {user?.balance.toLocaleString() || 0}
                </p>
              </div>
            </div>
            {gameState !== 'betting' && (
              <div>
                <p className="text-xs text-zinc-400">Apuesta</p>
                <p className="text-xl font-bold text-yellow-500">{betAmount}</p>
              </div>
            )}
          </div>

          {/* Dealer Hand */}
          {gameState !== 'betting' && (
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <UserCircle className="w-6 h-6 text-white" />
                <h3 className="text-lg font-bold text-white">
                  Dealer {gameState !== 'playing' && `(${calculateHandValue(dealerHand)})`}
                </h3>
              </div>
              <div className="flex gap-3 justify-center">
                {dealerHand.map((card, index) => (
                  <div key={index}>{renderCard(card, index === 1 && gameState === 'playing')}</div>
                ))}
              </div>
            </div>
          )}

          {/* Player Hand */}
          {gameState !== 'betting' && (
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <Hand className="w-6 h-6 text-yellow-500" />
                <h3 className="text-lg font-bold text-white">
                  Tu Mano ({calculateHandValue(playerHand)})
                </h3>
              </div>
              <div className="flex gap-3 justify-center">
                {playerHand.map((card, index) => (
                  <div key={index}>{renderCard(card)}</div>
                ))}
              </div>
            </div>
          )}

          {/* Betting Phase */}
          {gameState === 'betting' && (
            <div className="bg-zinc-900/50 rounded-xl p-6 space-y-4">
              <h3 className="text-lg font-bold text-white text-center">Haz tu apuesta</h3>
              <div className="flex gap-2 justify-center flex-wrap">
                {[25, 50, 100, 250, 500].map((amount) => (
                  <button
                    key={amount}
                    onClick={() => setBetAmount(amount)}
                    className={`px-6 py-3 rounded-lg font-semibold transition-all ${
                      betAmount === amount
                        ? 'bg-yellow-500 text-black'
                        : 'bg-zinc-700 text-zinc-300 hover:bg-zinc-600'
                    }`}
                  >
                    {amount}
                  </button>
                ))}
              </div>
              <Button
                onClick={startGame}
                className="w-full bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-black font-bold text-lg py-6"
              >
                <PlayCircle className="w-5 h-5 mr-2" />
                JUGAR ({betAmount} fichas)
              </Button>
            </div>
          )}

          {/* Playing Phase */}
          {gameState === 'playing' && (
            <div className="flex gap-3">
              <Button
                onClick={hit}
                className="flex-1 bg-yellow-500 hover:bg-yellow-600 text-black font-bold text-lg py-6"
              >
                Pedir Carta
              </Button>
              <Button
                onClick={() => stand()}
                className="flex-1 bg-red-600 hover:bg-red-700 text-white font-bold text-lg py-6"
              >
                Plantarse
              </Button>
            </div>
          )}

          {/* Finished Phase */}
          {gameState === 'finished' && (
            <Button
              onClick={reset}
              className="w-full bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-black font-bold text-lg py-6"
            >
              Nueva Partida
            </Button>
          )}

          <p className="text-xs text-center text-zinc-300">
            💰 Moneda virtual sin valor real. Juega responsablemente.
          </p>

          {/* Anuncio Temu */}
          <div className="mt-4">
            <TemuAd variant="inline" />
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}