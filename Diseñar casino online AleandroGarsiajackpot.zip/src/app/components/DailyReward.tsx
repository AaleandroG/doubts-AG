import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Gift, Coins, Calendar, Clock } from 'lucide-react';
import { useUser } from '../contexts/UserContext';

export function DailyReward() {
  const { user, canClaimDailyReward, claimDailyReward } = useUser();
  const [open, setOpen] = useState(false);
  const [timeLeft, setTimeLeft] = useState('');

  useEffect(() => {
    if (user && canClaimDailyReward()) {
      // Mostrar modal después de 2 segundos si puede reclamar
      const timer = setTimeout(() => {
        setOpen(true);
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, [user, canClaimDailyReward]);

  useEffect(() => {
    if (!user || canClaimDailyReward()) return;

    const updateTimer = () => {
      const lastClaim = new Date(user.lastDailyReward!);
      const nextClaim = new Date(lastClaim.getTime() + 24 * 60 * 60 * 1000);
      const now = new Date();
      const diff = nextClaim.getTime() - now.getTime();

      if (diff <= 0) {
        setTimeLeft('¡Disponible ahora!');
        return;
      }

      const hours = Math.floor(diff / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      setTimeLeft(`${hours}h ${minutes}m`);
    };

    updateTimer();
    const interval = setInterval(updateTimer, 60000); // Actualizar cada minuto

    return () => clearInterval(interval);
  }, [user, canClaimDailyReward]);

  const handleClaim = () => {
    if (claimDailyReward()) {
      setOpen(false);
    }
  };

  if (!user) return null;

  return (
    <>
      {/* Botón flotante para abrir recompensas */}
      <button
        onClick={() => setOpen(true)}
        className="fixed left-4 top-24 lg:top-28 z-40 bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-black rounded-full p-2 lg:p-3 shadow-lg transition-all hover:scale-110"
        title="Recompensa Diaria"
      >
        <Gift className="w-5 h-5 lg:w-6 lg:h-6" />
        {canClaimDailyReward() && (
          <div className="absolute -top-1 -right-1 w-3 h-3 lg:w-4 lg:h-4 bg-red-500 rounded-full animate-pulse"></div>
        )}
      </button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-md bg-zinc-900 border-zinc-800">
          <DialogHeader>
            <div className="flex items-center justify-center mb-4">
              <div className="bg-gradient-to-r from-yellow-500 to-orange-500 rounded-full p-4">
                <Gift className="w-12 h-12 text-black" />
              </div>
            </div>
            <DialogTitle className="text-2xl text-center text-white">
              Recompensa Diaria
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-6">
            {canClaimDailyReward() ? (
              <>
                <div className="bg-zinc-800/50 rounded-xl p-6 text-center">
                  <Coins className="w-16 h-16 text-yellow-500 mx-auto mb-3" />
                  <p className="text-3xl font-bold text-white mb-2">+250</p>
                  <p className="text-zinc-400">Fichas Jackpot</p>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center gap-3 text-sm text-zinc-400">
                    <Calendar className="w-5 h-5 text-yellow-500" />
                    <span>Recompensa disponible cada 24 horas</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm text-zinc-400">
                    <Coins className="w-5 h-5 text-yellow-500" />
                    <span>Usa tus fichas para jugar en el casino</span>
                  </div>
                </div>

                <Button
                  onClick={handleClaim}
                  className="w-full bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-black font-bold text-lg py-6"
                >
                  Reclamar Recompensa
                </Button>
              </>
            ) : (
              <>
                <div className="bg-zinc-800/50 rounded-xl p-6 text-center">
                  <Clock className="w-16 h-16 text-zinc-600 mx-auto mb-3" />
                  <p className="text-2xl font-bold text-white mb-2">Ya reclamada</p>
                  <p className="text-zinc-400">Próxima recompensa en:</p>
                  <p className="text-3xl font-bold text-yellow-500 mt-3">{timeLeft}</p>
                </div>

                <div className="bg-zinc-800/30 rounded-lg p-4">
                  <p className="text-sm text-zinc-400 text-center">
                    Vuelve mañana para reclamar tu siguiente recompensa diaria de{' '}
                    <span className="text-yellow-400 font-semibold">250 Fichas Jackpot</span>
                  </p>
                </div>

                <Button
                  onClick={() => setOpen(false)}
                  variant="outline"
                  className="w-full border-zinc-700 text-white hover:bg-zinc-800"
                >
                  Cerrar
                </Button>
              </>
            )}

            <p className="text-xs text-center text-zinc-500">
              💰 Las Fichas Jackpot son moneda virtual sin valor real. Solo para entretenimiento.
            </p>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}