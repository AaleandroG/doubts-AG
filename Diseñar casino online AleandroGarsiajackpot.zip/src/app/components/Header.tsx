import { useState } from 'react';
import { Crown, Menu, X, Search, Home, Gamepad2, Trophy, Ticket, Star, Mail } from 'lucide-react';
import { Button } from './ui/button';
import { useUser } from '../contexts/UserContext';

interface HeaderProps {
  onLoginClick: () => void;
  onRegisterClick: () => void;
}

export function Header({ onLoginClick, onRegisterClick }: HeaderProps) {
  const { isLoggedIn } = useUser();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);

  const menuItems = [
    { icon: Home, label: 'Inicio', href: '#' },
    { icon: Gamepad2, label: 'Juegos', href: '#games' },
    { icon: Trophy, label: 'Rankings', href: '#rankings' },
    { icon: Star, label: 'Casino en Vivo', href: '#live' },
    { icon: Ticket, label: 'Promociones', href: '#promotions' },
    { icon: Mail, label: 'Contacto', href: '#footer' },
  ];

  const handleMenuClick = (href: string) => {
    setMobileMenuOpen(false);
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-zinc-950/95 backdrop-blur-md border-b border-zinc-800">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16 lg:h-20">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <Crown className="w-8 h-8 lg:w-10 lg:h-10 text-yellow-500" />
            <div>
              <h1 className="text-lg lg:text-xl font-bold bg-gradient-to-r from-yellow-400 to-yellow-600 bg-clip-text text-transparent">
                AleandroGarsiajackpot
              </h1>
              <p className="text-[10px] text-zinc-500 hidden lg:block">Casino Virtual Premium</p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-1">
            {menuItems.map((item) => (
              <button
                key={item.label}
                onClick={() => handleMenuClick(item.href)}
                className="flex items-center gap-2 px-4 py-2 text-zinc-300 hover:text-yellow-400 hover:bg-zinc-800/50 rounded-lg transition-all font-medium"
              >
                <item.icon className="w-4 h-4" />
                <span className="text-sm">{item.label}</span>
              </button>
            ))}
          </nav>

          {/* Search & Actions */}
          <div className="flex items-center gap-2 lg:gap-3">
            {/* Search Button */}
            <button
              onClick={() => setSearchOpen(!searchOpen)}
              className="p-2 text-zinc-400 hover:text-white hover:bg-zinc-800 rounded-lg transition-all"
              title="Buscar juegos"
            >
              <Search className="w-5 h-5" />
            </button>

            {/* Auth Buttons - Desktop */}
            {!isLoggedIn && (
              <div className="hidden lg:flex items-center gap-2">
                <Button
                  onClick={onLoginClick}
                  variant="ghost"
                  className="text-zinc-300 hover:text-white hover:bg-zinc-800"
                >
                  Iniciar Sesión
                </Button>
                <Button
                  onClick={onRegisterClick}
                  className="bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-black font-bold"
                >
                  Registrarse
                </Button>
              </div>
            )}

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-zinc-400 hover:text-white hover:bg-zinc-800 rounded-lg transition-all"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Search Bar */}
        {searchOpen && (
          <div className="pb-4 animate-in slide-in-from-top">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-zinc-400" />
              <input
                type="text"
                placeholder="Buscar juegos, slots, ruleta..."
                className="w-full bg-zinc-900 border border-zinc-700 rounded-lg pl-10 pr-4 py-3 text-white placeholder:text-zinc-500 focus:outline-none focus:border-yellow-500"
                autoFocus
              />
            </div>
          </div>
        )}
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-zinc-900 border-t border-zinc-800 animate-in slide-in-from-top">
          <nav className="container mx-auto px-4 py-4">
            <div className="flex flex-col gap-2">
              {menuItems.map((item) => (
                <button
                  key={item.label}
                  onClick={() => handleMenuClick(item.href)}
                  className="flex items-center gap-3 px-4 py-3 text-zinc-300 hover:text-yellow-400 hover:bg-zinc-800 rounded-lg transition-all"
                >
                  <item.icon className="w-5 h-5" />
                  <span className="font-medium">{item.label}</span>
                </button>
              ))}

              {!isLoggedIn && (
                <div className="flex flex-col gap-2 mt-4 pt-4 border-t border-zinc-800">
                  <Button
                    onClick={onLoginClick}
                    variant="outline"
                    className="w-full border-zinc-700 text-white hover:bg-zinc-800"
                  >
                    Iniciar Sesión
                  </Button>
                  <Button
                    onClick={onRegisterClick}
                    className="w-full bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-black font-bold"
                  >
                    Registrarse
                  </Button>
                </div>
              )}
            </div>
          </nav>
        </div>
      )}
    </header>
  );
}