import { Play, Star } from 'lucide-react';

interface GameCardProps {
  title: string;
  image: string;
  category: string;
  isNew?: boolean;
  isHot?: boolean;
  rtp?: string;
  onPlay?: () => void;
}

export function GameCard({ title, image, category, isNew, isHot, rtp, onPlay }: GameCardProps) {
  return (
    <div className="group relative bg-zinc-900 rounded-xl overflow-hidden border border-zinc-800 hover:border-yellow-500/50 transition-all duration-300 hover:transform hover:scale-105 hover:shadow-2xl hover:shadow-yellow-500/20">
      {/* Image Container */}
      <div className="relative aspect-[4/3] overflow-hidden">
        <img
          src={image}
          alt={title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        
        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-zinc-900 via-zinc-900/50 to-transparent opacity-60 group-hover:opacity-80 transition-opacity" />
        
        {/* Badges */}
        <div className="absolute top-2 left-2 flex gap-2">
          {isNew && (
            <span className="bg-green-500 text-black text-xs font-bold px-2 py-1 rounded-full">
              NUEVO
            </span>
          )}
          {isHot && (
            <span className="bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full animate-pulse">
              🔥 HOT
            </span>
          )}
        </div>

        {/* RTP Badge */}
        {rtp && (
          <div className="absolute top-2 right-2 bg-yellow-500/90 backdrop-blur-sm text-black text-xs font-bold px-2 py-1 rounded-full">
            RTP {rtp}
          </div>
        )}
        
        {/* Play Button Overlay */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
          <button
            onClick={onPlay}
            className="bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-black font-bold px-6 py-3 rounded-full flex items-center gap-2 transform scale-90 group-hover:scale-100 transition-transform shadow-lg"
          >
            <Play className="w-5 h-5 fill-current" />
            JUGAR
          </button>
        </div>
      </div>
      
      {/* Content */}
      <div className="p-4">
        <div className="flex items-start justify-between gap-2 mb-2">
          <h3 className="text-white font-bold text-sm line-clamp-2 flex-1">
            {title}
          </h3>
          <div className="flex items-center gap-1 text-yellow-500 flex-shrink-0">
            <Star className="w-4 h-4 fill-current" />
            <span className="text-xs font-semibold">
              {(Math.random() * 0.5 + 4.5).toFixed(1)}
            </span>
          </div>
        </div>
        
        <p className="text-zinc-400 text-xs mb-3">{category}</p>
        
        <button
          onClick={onPlay}
          className="w-full bg-zinc-800 hover:bg-yellow-500 text-zinc-300 hover:text-black font-semibold py-2 px-4 rounded-lg transition-all text-sm"
        >
          Jugar Ahora
        </button>
      </div>
    </div>
  );
}