import { Button } from './ui/button';
import { Video, Users, Clock } from 'lucide-react';
import { toast } from 'sonner';
import { useState } from 'react';

export function LiveCasino() {
  const [selectedGame, setSelectedGame] = useState<string | null>(null);

  const handleGameClick = (gameName: string) => {
    setSelectedGame(gameName);
    toast.info(`Cargando ${gameName}...`, {
      description: 'Conectando con dealer en vivo',
    });
    setTimeout(() => setSelectedGame(null), 2000);
  };

  const liveGames = [
    { name: 'Ruleta', image: 'https://images.unsplash.com/photo-1633629544357-14223c9837d2?w=800' },
    { name: 'Blackjack', image: 'https://images.unsplash.com/photo-1633629544357-14223c9837d2?w=800' },
    { name: 'Baccarat', image: 'https://images.unsplash.com/photo-1633629544357-14223c9837d2?w=800' },
    { name: 'Poker', image: 'https://images.unsplash.com/photo-1633629544357-14223c9837d2?w=800' },
  ];

  return (
    <section id="live" className="py-16 lg:py-24 bg-zinc-900">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
          {/* Image Side */}
          <div className="relative rounded-2xl overflow-hidden">
            <img
              src={selectedGame ? liveGames.find(game => game.name === selectedGame)?.image : "https://images.unsplash.com/photo-1633629544357-14223c9837d2?w=800"}
              alt="Casino en Vivo"
              className="w-full h-full object-cover min-h-[400px]"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent"></div>
            
            {/* Live Badge */}
            <div className="absolute top-6 left-6 flex items-center gap-2 bg-red-600 text-white px-4 py-2 rounded-full font-semibold">
              <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
              EN VIVO
            </div>

            {/* Stats Overlay */}
            <div className="absolute bottom-6 left-6 right-6 flex justify-between">
              <div className="bg-black/60 backdrop-blur-sm rounded-lg px-4 py-2">
                <div className="flex items-center gap-2 text-white">
                  <Users className="w-4 h-4" />
                  <span className="text-sm font-semibold">2,847 jugando</span>
                </div>
              </div>
              <div className="bg-black/60 backdrop-blur-sm rounded-lg px-4 py-2">
                <div className="flex items-center gap-2 text-white">
                  <Clock className="w-4 h-4" />
                  <span className="text-sm font-semibold">24/7</span>
                </div>
              </div>
            </div>
          </div>

          {/* Content Side */}
          <div>
            <div className="inline-flex items-center gap-2 bg-red-500/20 border border-red-500/50 rounded-full px-4 py-2 mb-6">
              <Video className="w-4 h-4 text-red-400" />
              <span className="text-sm text-red-400 font-semibold">
                Transmisión en HD
              </span>
            </div>

            <h2 className="text-3xl lg:text-5xl font-bold text-white mb-6">
              Casino en Vivo
            </h2>
            <p className="text-xl text-zinc-300 mb-8">
              Experimenta la emoción de un casino real desde la comodidad de tu hogar
            </p>

            <div className="space-y-4 mb-8">
              <div className="flex items-start gap-3">
                <div className="bg-yellow-500 rounded-full p-1 mt-1">
                  <div className="w-2 h-2 bg-zinc-900 rounded-full"></div>
                </div>
                <div>
                  <h4 className="text-white font-semibold mb-1">Crupieres Profesionales</h4>
                  <p className="text-zinc-400">
                    Dealers reales que interactúan contigo en tiempo real
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="bg-yellow-500 rounded-full p-1 mt-1">
                  <div className="w-2 h-2 bg-zinc-900 rounded-full"></div>
                </div>
                <div>
                  <h4 className="text-white font-semibold mb-1">Múltiples Mesas</h4>
                  <p className="text-zinc-400">
                    Ruleta, Blackjack, Baccarat, Poker y más
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="bg-yellow-500 rounded-full p-1 mt-1">
                  <div className="w-2 h-2 bg-zinc-900 rounded-full"></div>
                </div>
                <div>
                  <h4 className="text-white font-semibold mb-1">Límites Flexibles</h4>
                  <p className="text-zinc-400">
                    Desde apuestas mínimas hasta mesas VIP exclusivas
                  </p>
                </div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                onClick={handleGameClick}
                size="lg"
                className="bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-black font-bold"
              >
                Jugar en Vivo
              </Button>
              <Button
                onClick={handleGameClick}
                size="lg"
                variant="outline"
                className="border-zinc-700 text-white hover:bg-zinc-800"
              >
                Ver todas las mesas
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}