import { GameCard } from './GameCard';
import { Flame } from 'lucide-react';
import { useState } from 'react';
import { RealisticSlot } from './games/RealisticSlot';
import { Roulette } from './games/Roulette';
import { Blackjack } from './games/Blackjack';
import { VideoPoker } from './games/VideoPoker';

export function FeaturedGames() {
  const [selectedGame, setSelectedGame] = useState<{
    type: 'slot' | 'roulette' | 'blackjack' | 'poker' | null;
    name: string;
    theme?: 'classic' | 'diamond' | 'golden' | 'fruit';
  } | null>(null);

  const handleGameClick = (
    type: 'slot' | 'roulette' | 'blackjack' | 'poker',
    name: string,
    theme?: 'classic' | 'diamond' | 'golden' | 'fruit'
  ) => {
    setSelectedGame({ type, name, theme });
  };

  const games = [
    {
      title: 'Mega Fortune™ Deluxe',
      image: 'https://images.unsplash.com/photo-1596838132731-3301c3fd4317?w=400&h=300&fit=crop',
      category: 'Slots Premium',
      isNew: true,
      type: 'slot' as const,
      theme: 'diamond' as const,
      rtp: '96.5%',
    },
    {
      title: 'Ruleta Europea Pro',
      image: 'https://images.unsplash.com/photo-1511193311914-0346f16efe90?w=400&h=300&fit=crop',
      category: 'Ruleta',
      isHot: true,
      type: 'roulette' as const,
      rtp: '97.3%',
    },
    {
      title: 'Blackjack Premium VIP',
      image: 'https://images.unsplash.com/photo-1541278107931-e006523892df?w=400&h=300&fit=crop',
      category: 'Cartas',
      isHot: true,
      type: 'blackjack' as const,
      rtp: '99.5%',
    },
    {
      title: 'Diamond Jackpot Slots',
      image: 'https://images.unsplash.com/photo-1529310399831-ed472b81d589?w=400&h=300&fit=crop',
      category: 'Slots Jackpot',
      isNew: true,
      type: 'slot' as const,
      theme: 'diamond' as const,
      rtp: '95.8%',
    },
    {
      title: 'Golden Reels™ Mega',
      image: 'https://images.unsplash.com/photo-1470058869958-2a77ade41c02?w=400&h=300&fit=crop',
      category: 'Slots Classic',
      type: 'slot' as const,
      theme: 'golden' as const,
      rtp: '96.2%',
    },
    {
      title: 'Video Poker Jacks or Better',
      image: 'https://images.unsplash.com/photo-1571902943202-507ec2618e8f?w=400&h=300&fit=crop',
      category: 'Video Poker',
      type: 'poker' as const,
      rtp: '99.5%',
      isNew: true,
    },
    {
      title: 'Lucky Fruits™ 777',
      image: 'https://images.unsplash.com/photo-1516975080664-ed2fc6a32937?w=400&h=300&fit=crop',
      category: 'Slots Frutas',
      isHot: true,
      type: 'slot' as const,
      theme: 'fruit' as const,
      rtp: '96.8%',
    },
    {
      title: 'Classic Slots™ Bar',
      image: 'https://images.unsplash.com/photo-1564086186361-2a1c9f3c86ea?w=400&h=300&fit=crop',
      category: 'Slots Retro',
      type: 'slot' as const,
      theme: 'classic' as const,
      rtp: '95.5%',
    },
  ];

  return (
    <section id="games" className="py-16 lg:py-24 bg-zinc-950">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="flex items-center gap-3 mb-8">
          <Flame className="w-8 h-8 text-yellow-500" />
          <h2 className="text-3xl lg:text-4xl font-bold text-white">
            Juegos Destacados
          </h2>
        </div>

        {/* Games Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 lg:gap-6">
          {games.map((game, index) => (
            <GameCard
              key={index}
              {...game}
              onPlay={() => handleGameClick(game.type, game.title, game.theme)}
            />
          ))}
        </div>
      </div>

      {/* Game Modals */}
      {selectedGame?.type === 'slot' && (
        <RealisticSlot
          open={true}
          onOpenChange={(open) => !open && setSelectedGame(null)}
          gameName={selectedGame.name}
          theme={selectedGame.theme}
        />
      )}
      {selectedGame?.type === 'roulette' && (
        <Roulette
          open={true}
          onOpenChange={(open) => !open && setSelectedGame(null)}
          gameName={selectedGame.name}
        />
      )}
      {selectedGame?.type === 'blackjack' && (
        <Blackjack
          open={true}
          onOpenChange={(open) => !open && setSelectedGame(null)}
          gameName={selectedGame.name}
        />
      )}
      {selectedGame?.type === 'poker' && (
        <VideoPoker
          open={true}
          onOpenChange={(open) => !open && setSelectedGame(null)}
          gameName={selectedGame.name}
        />
      )}
    </section>
  );
}