import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { X, Cookie } from 'lucide-react';
import { toast } from 'sonner';

export function CookieBanner() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Check if user has already accepted cookies
    const cookiesAccepted = localStorage.getItem('cookiesAccepted');
    if (!cookiesAccepted) {
      // Show banner after 2 seconds
      setTimeout(() => {
        setIsVisible(true);
      }, 2000);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('cookiesAccepted', 'true');
    setIsVisible(false);
    toast.success('Preferencias guardadas', {
      description: 'Has aceptado el uso de cookies',
    });
  };

  const handleReject = () => {
    localStorage.setItem('cookiesAccepted', 'rejected');
    setIsVisible(false);
    toast.info('Cookies rechazadas', {
      description: 'Solo usaremos cookies esenciales',
    });
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 p-4 md:p-6 animate-in slide-in-from-bottom">
      <div className="container mx-auto">
        <div className="bg-zinc-900 border border-zinc-700 rounded-2xl p-6 md:p-8 shadow-2xl max-w-4xl mx-auto">
          <button
            onClick={handleReject}
            className="absolute top-4 right-4 text-zinc-400 hover:text-white transition-colors"
            aria-label="Cerrar"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex flex-col md:flex-row gap-6 items-start md:items-center">
            <div className="bg-yellow-500/20 rounded-full p-4 flex-shrink-0">
              <Cookie className="w-8 h-8 text-yellow-500" />
            </div>

            <div className="flex-1">
              <h3 className="text-xl font-bold text-white mb-2">
                🍪 Usamos cookies
              </h3>
              <p className="text-zinc-300 text-sm mb-4">
                Utilizamos cookies para mejorar tu experiencia de juego, personalizar contenido y analizar nuestro tráfico.
                Al hacer clic en "Aceptar", aceptas el uso de cookies según nuestra{' '}
                <button className="text-yellow-400 hover:text-yellow-300 underline">
                  Política de Privacidad
                </button>
                .
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto">
              <Button
                onClick={handleReject}
                variant="outline"
                className="border-zinc-700 text-zinc-300 hover:bg-zinc-800 w-full sm:w-auto"
              >
                Rechazar
              </Button>
              <Button
                onClick={handleAccept}
                className="bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-black font-semibold w-full sm:w-auto"
              >
                Aceptar Cookies
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
