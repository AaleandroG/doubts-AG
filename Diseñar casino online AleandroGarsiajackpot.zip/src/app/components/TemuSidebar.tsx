import { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { TemuAd } from './TemuAd';

export function TemuSidebar() {
  const [isVisible, setIsVisible] = useState(true);
  const [isSticky, setIsSticky] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      // Mostrar sidebar sticky después de hacer scroll
      if (window.scrollY > 400) {
        setIsSticky(true);
      } else {
        setIsSticky(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  if (!isVisible || !isSticky) return null;

  return (
    <div className="fixed right-4 bottom-4 z-40 w-64 animate-in slide-in-from-bottom">
      <div className="relative">
        <button
          onClick={() => setIsVisible(false)}
          className="absolute -top-2 -right-2 bg-zinc-900 hover:bg-zinc-800 rounded-full p-1 z-10 border border-zinc-700"
          title="Cerrar"
        >
          <X className="w-4 h-4 text-white" />
        </button>
        <TemuAd variant="sidebar" />
      </div>
    </div>
  );
}
