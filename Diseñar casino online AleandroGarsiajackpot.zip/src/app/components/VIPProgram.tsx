import { Button } from './ui/button';
import { Crown, Star, Gem, Award } from 'lucide-react';
import { toast } from 'sonner';

export function VIPProgram() {
  const handleJoinVIP = () => {
    toast.success('¡Bienvenido al Club VIP!', {
      description: 'Un gestor personal se pondrá en contacto contigo pronto',
    });
  };

  const benefits = [
    {
      icon: Crown,
      title: 'Gestor Personal',
      description: 'Atención exclusiva 24/7',
    },
    {
      icon: Star,
      title: 'Cashback Premium',
      description: 'Hasta 25% de reembolso',
    },
    {
      icon: Gem,
      title: 'Bonos Exclusivos',
      description: 'Ofertas personalizadas',
    },
    {
      icon: Award,
      title: 'Eventos VIP',
      description: 'Acceso a torneos privados',
    },
  ];

  return (
    <section id="vip" className="py-16 lg:py-24 bg-zinc-950 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 opacity-10">
        <img
          src="https://images.unsplash.com/photo-1563107976-3375fc7a53db?w=1200"
          alt="VIP"
          className="w-full h-full object-cover"
        />
      </div>
      <div className="absolute inset-0 bg-gradient-to-b from-zinc-950 via-zinc-950/95 to-zinc-950"></div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 bg-yellow-500/20 border border-yellow-500/50 rounded-full px-6 py-2 mb-6">
              <Crown className="w-5 h-5 text-yellow-400" />
              <span className="text-sm text-yellow-400 font-semibold">
                Programa Exclusivo
              </span>
            </div>

            <h2 className="text-4xl lg:text-5xl font-bold mb-6">
              <span className="text-white">Programa </span>
              <span className="bg-gradient-to-r from-yellow-400 to-yellow-600 bg-clip-text text-transparent">
                VIP
              </span>
            </h2>

            <p className="text-xl text-zinc-300 mb-8">
              Disfruta de privilegios exclusivos y beneficios premium diseñados para nuestros jugadores más leales
            </p>
          </div>

          {/* Benefits Grid */}
          <div className="grid md:grid-cols-2 gap-6 mb-12">
            {benefits.map((benefit, index) => {
              const Icon = benefit.icon;
              return (
                <div
                  key={index}
                  className="bg-gradient-to-br from-zinc-800 to-zinc-900 border border-yellow-500/20 rounded-xl p-6 hover:border-yellow-500/50 transition-all"
                >
                  <div className="bg-gradient-to-br from-yellow-500 to-yellow-600 rounded-lg w-14 h-14 flex items-center justify-center mb-4">
                    <Icon className="w-7 h-7 text-black" />
                  </div>
                  <h3 className="text-xl font-bold text-white mb-2">
                    {benefit.title}
                  </h3>
                  <p className="text-zinc-400">
                    {benefit.description}
                  </p>
                </div>
              );
            })}
          </div>

          {/* VIP Levels */}
          <div className="bg-gradient-to-r from-zinc-800 to-zinc-900 rounded-2xl p-8 border border-yellow-500/30 mb-8">
            <h3 className="text-2xl font-bold text-white mb-6 text-center">
              Niveles VIP
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {['Bronce', 'Plata', 'Oro', 'Platino'].map((level, index) => (
                <div
                  key={index}
                  className="text-center p-4 rounded-lg bg-zinc-950/50 border border-zinc-700"
                >
                  <div className={`w-12 h-12 mx-auto mb-3 rounded-full bg-gradient-to-br ${
                    index === 0 ? 'from-orange-400 to-orange-600' :
                    index === 1 ? 'from-gray-300 to-gray-500' :
                    index === 2 ? 'from-yellow-400 to-yellow-600' :
                    'from-purple-400 to-purple-600'
                  } flex items-center justify-center`}>
                    <Crown className="w-6 h-6 text-white" />
                  </div>
                  <p className="text-white font-semibold">{level}</p>
                </div>
              ))}
            </div>
          </div>

          {/* CTA */}
          <div className="text-center">
            <Button
              onClick={handleJoinVIP}
              size="lg"
              className="bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-black font-bold text-lg px-12 py-6"
            >
              Únete al Club VIP
            </Button>
            <p className="text-sm text-zinc-400 mt-4">
              Sujeto a términos y condiciones del programa VIP
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}