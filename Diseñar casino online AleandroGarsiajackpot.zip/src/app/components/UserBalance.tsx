import { Coins } from 'lucide-react';
import { useUser } from '../contexts/UserContext';

export function UserBalance() {
  const { user } = useUser();

  if (!user) return null;

  return (
    <div className="fixed top-28 right-4 z-40 bg-gradient-to-r from-yellow-500 to-orange-500 text-black rounded-xl shadow-2xl p-4 border-2 border-yellow-400 animate-in slide-in-from-top">
      <div className="flex items-center gap-3">
        <div className="bg-black/20 rounded-full p-2">
          <Coins className="w-6 h-6" />
        </div>
        <div>
          <p className="text-xs font-semibold opacity-90">Fichas Jackpot</p>
          <p className="text-2xl font-bold">{user.balance.toLocaleString()}</p>
        </div>
      </div>
      <p className="text-xs text-center mt-2 opacity-80">
        💰 Se recargan 1000 fichas cada día
      </p>
    </div>
  );
}