import { Button } from './ui/button';
import { Gift, Sparkles } from 'lucide-react';

interface HeroProps {
  onRegisterClick: () => void;
}

export function Hero({ onRegisterClick }: HeroProps) {
  const handleExploreGames = () => {
    const element = document.querySelector('#games');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <section id="hero" className="relative pt-24 lg:pt-32 pb-16 lg:pb-24 overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1759701547315-cc8b7f2100f3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXNpbm8lMjByb3VsZXR0ZSUyMGx1eHVyeXxlbnwxfHx8fDE3NzA2NDQ4MDd8MA&ixlib=rb-4.1.0&q=80&w=1080"
          alt="Casino"
          className="w-full h-full object-cover opacity-30"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-zinc-900 via-zinc-900/90 to-transparent"></div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-3xl">
          {/* Promo Badge */}
          <div className="inline-flex items-center gap-2 bg-yellow-500/20 backdrop-blur-sm border border-yellow-500/50 rounded-full px-6 py-2 mb-6">
            <Gift className="w-5 h-5 text-yellow-400" />
            <span className="text-yellow-400 font-semibold">
              ¡Nuevo! Bono de Bienvenida
            </span>
          </div>

          {/* Main Headline */}
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight">
            Tu Casino Online
            <span className="block bg-gradient-to-r from-yellow-400 to-yellow-600 bg-clip-text text-transparent">
              De Entretenimiento
            </span>
          </h1>

          {/* Subheadline */}
          <p className="text-lg lg:text-xl text-zinc-300 mb-8 max-w-2xl">
            Juega con fichas virtuales. 1000 Fichas Jackpot gratis al registrarte.
            Entretenimiento garantizado sin riesgo real.
          </p>

          {/* Offer */}
          <div className="bg-gradient-to-r from-yellow-500 to-yellow-600 rounded-2xl p-6 lg:p-8 mb-8 shadow-2xl">
            <div className="flex items-start gap-4">
              <Gift className="w-12 h-12 text-black flex-shrink-0" />
              <div>
                <h2 className="text-2xl lg:text-3xl font-bold text-black mb-2">
                  100% hasta 500€
                </h2>
                <p className="text-lg text-black/90 mb-3">
                  + 100 Tiradas Gratis en slots seleccionados
                </p>
                <p className="text-sm text-black/75">
                  En tu primer depósito. Términos y condiciones aplicables.
                </p>
              </div>
            </div>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4">
            <Button
              onClick={onRegisterClick}
              size="lg"
              className="bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-black font-bold text-lg px-8 py-6"
            >
              Jugar Ahora
            </Button>
            <Button
              onClick={handleExploreGames}
              size="lg"
              variant="outline"
              className="border-zinc-700 text-white hover:bg-zinc-800 text-lg px-8 py-6"
            >
              Explorar Juegos
            </Button>
          </div>

          {/* Trust Indicators */}
          <div className="flex flex-wrap items-center gap-6 pt-8">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-yellow-400" />
              <span className="text-sm text-zinc-400">Fichas virtuales gratis</span>
            </div>
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-yellow-400" />
              <span className="text-sm text-zinc-400">Juegos certificados</span>
            </div>
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-yellow-400" />
              <span className="text-sm text-zinc-400">100% entretenimiento</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}