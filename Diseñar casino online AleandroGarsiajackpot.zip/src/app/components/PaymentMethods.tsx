import { CreditCard, Smartphone, DollarSign, Lock } from 'lucide-react';

export function PaymentMethods() {
  return (
    <section className="py-16 lg:py-24 bg-zinc-900">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold text-white mb-4">
            Información del Sistema
          </h2>
          <p className="text-lg text-zinc-400 max-w-2xl mx-auto">
            💰 Este casino utiliza exclusivamente moneda virtual (Fichas Jackpot) sin valor real.
            No hay transacciones monetarias reales.
          </p>
        </div>

        {/* Payment Icons */}
        <div className="max-w-5xl mx-auto mb-12">
          <div className="grid grid-cols-3 md:grid-cols-6 gap-6 mb-8">
            {/* Visa */}
            <div className="bg-zinc-800 rounded-xl p-4 flex items-center justify-center border border-zinc-700 hover:border-yellow-500/50 transition-all">
              <div className="text-center">
                <CreditCard className="w-8 h-8 text-blue-400 mx-auto mb-2" />
                <p className="text-xs text-zinc-400">Visa</p>
              </div>
            </div>

            {/* Mastercard */}
            <div className="bg-zinc-800 rounded-xl p-4 flex items-center justify-center border border-zinc-700 hover:border-yellow-500/50 transition-all">
              <div className="text-center">
                <CreditCard className="w-8 h-8 text-orange-400 mx-auto mb-2" />
                <p className="text-xs text-zinc-400">Mastercard</p>
              </div>
            </div>

            {/* Skrill */}
            <div className="bg-zinc-800 rounded-xl p-4 flex items-center justify-center border border-zinc-700 hover:border-yellow-500/50 transition-all">
              <div className="text-center">
                <Smartphone className="w-8 h-8 text-purple-400 mx-auto mb-2" />
                <p className="text-xs text-zinc-400">Skrill</p>
              </div>
            </div>

            {/* Neteller */}
            <div className="bg-zinc-800 rounded-xl p-4 flex items-center justify-center border border-zinc-700 hover:border-yellow-500/50 transition-all">
              <div className="text-center">
                <Smartphone className="w-8 h-8 text-green-400 mx-auto mb-2" />
                <p className="text-xs text-zinc-400">Neteller</p>
              </div>
            </div>

            {/* Crypto */}
            <div className="bg-zinc-800 rounded-xl p-4 flex items-center justify-center border border-zinc-700 hover:border-yellow-500/50 transition-all">
              <div className="text-center">
                <DollarSign className="w-8 h-8 text-yellow-400 mx-auto mb-2" />
                <p className="text-xs text-zinc-400">Bitcoin</p>
              </div>
            </div>

            {/* Bank Transfer */}
            <div className="bg-zinc-800 rounded-xl p-4 flex items-center justify-center border border-zinc-700 hover:border-yellow-500/50 transition-all">
              <div className="text-center">
                <CreditCard className="w-8 h-8 text-cyan-400 mx-auto mb-2" />
                <p className="text-xs text-zinc-400">Transferencia</p>
              </div>
            </div>
          </div>
        </div>

        {/* Security Features */}
        <div className="max-w-4xl mx-auto">
          <div className="grid md:grid-cols-3 gap-6">
            <div className="bg-zinc-800 rounded-xl p-6 border border-zinc-700 text-center">
              <Lock className="w-10 h-10 text-yellow-500 mx-auto mb-4" />
              <h3 className="text-white font-semibold mb-2">
                Encriptación SSL
              </h3>
              <p className="text-sm text-zinc-400 text-center">
                Todas las transacciones son seguras con encriptación SSL de 256 bits
              </p>
            </div>

            <div className="bg-zinc-800 rounded-xl p-6 border border-zinc-700 text-center">
              <div className="w-10 h-10 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-white font-bold text-xl">✓</span>
              </div>
              <h3 className="text-white font-semibold mb-2">
                Retiros Rápidos
              </h3>
              <p className="text-sm text-zinc-400">
                Procesos de retiro en menos de 24 horas
              </p>
            </div>

            <div className="bg-zinc-800 rounded-xl p-6 border border-zinc-700 text-center">
              <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <CreditCard className="w-5 h-5 text-white" />
              </div>
              <h3 className="text-white font-semibold mb-2">
                Sin Comisiones
              </h3>
              <p className="text-sm text-zinc-400">
                No cobramos tarifas en depósitos ni retiros
              </p>
            </div>
          </div>
        </div>

        {/* Important Notice */}
        <div className="mt-12 bg-yellow-500/10 border border-yellow-500/50 rounded-xl p-6 text-center">
          <h3 className="text-xl font-bold text-yellow-500 mb-3">
            ⚠️ Aviso Importante
          </h3>
          <p className="text-zinc-300">
            Este es un casino de entretenimiento que utiliza únicamente <strong>Fichas Jackpot</strong> (moneda virtual sin valor real).
            No se realizan pagos ni cobros reales. Todo el contenido es solo para entretenimiento.
          </p>
        </div>
      </div>
    </section>
  );
}