import { Crown, Mail, Clock, Facebook, Twitter, Instagram, Youtube } from 'lucide-react';
import { toast } from 'sonner';

export function Footer() {
  const handleSocialClick = (platform: string) => {
    toast.info(`Abriendo ${platform}`, {
      description: 'Síguenos para ofertas exclusivas',
    });
  };

  const handleLinkClick = (section: string) => {
    toast.info(section, {
      description: 'Cargando información...',
    });
  };

  const handleContactClick = (method: string) => {
    toast.success(`Contactando por ${method}`, {
      description: 'Nuestro equipo está disponible 24/7',
    });
  };

  return (
    <footer id="footer" className="bg-zinc-950 border-t border-zinc-800">
      {/* Main Footer */}
      <div className="container mx-auto px-4 py-12 lg:py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Crown className="w-8 h-8 text-yellow-500" />
              <span className="text-lg font-bold bg-gradient-to-r from-yellow-400 to-yellow-600 bg-clip-text text-transparent">
                AleandroGarsiajackpot
              </span>
            </div>
            <p className="text-zinc-400 text-sm mb-6">
              Tu destino premium para juegos de casino online. Experimenta la emoción del casino desde cualquier lugar.
            </p>
            
            {/* Social Media */}
            <div className="flex gap-3">
              <button
                onClick={() => handleSocialClick('Facebook')}
                className="bg-zinc-800 hover:bg-yellow-500 text-zinc-400 hover:text-black rounded-full p-2 transition-all"
              >
                <Facebook className="w-5 h-5" />
              </button>
              <button
                onClick={() => handleSocialClick('Twitter')}
                className="bg-zinc-800 hover:bg-yellow-500 text-zinc-400 hover:text-black rounded-full p-2 transition-all"
              >
                <Twitter className="w-5 h-5" />
              </button>
              <button
                onClick={() => handleSocialClick('Instagram')}
                className="bg-zinc-800 hover:bg-yellow-500 text-zinc-400 hover:text-black rounded-full p-2 transition-all"
              >
                <Instagram className="w-5 h-5" />
              </button>
              <button
                onClick={() => handleSocialClick('YouTube')}
                className="bg-zinc-800 hover:bg-yellow-500 text-zinc-400 hover:text-black rounded-full p-2 transition-all"
              >
                <Youtube className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Casino */}
          <div>
            <h4 className="text-white font-semibold mb-4">Casino</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <button onClick={() => handleLinkClick('Slots')} className="text-zinc-400 hover:text-yellow-400 transition-colors">
                  Slots
                </button>
              </li>
              <li>
                <button onClick={() => handleLinkClick('Casino en Vivo')} className="text-zinc-400 hover:text-yellow-400 transition-colors">
                  Casino en Vivo
                </button>
              </li>
              <li>
                <button onClick={() => handleLinkClick('Jackpots')} className="text-zinc-400 hover:text-yellow-400 transition-colors">
                  Jackpots
                </button>
              </li>
              <li>
                <button onClick={() => handleLinkClick('Juegos de Mesa')} className="text-zinc-400 hover:text-yellow-400 transition-colors">
                  Juegos de Mesa
                </button>
              </li>
              <li>
                <button onClick={() => handleLinkClick('Nuevos Juegos')} className="text-zinc-400 hover:text-yellow-400 transition-colors">
                  Nuevos Juegos
                </button>
              </li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h4 className="text-white font-semibold mb-4">Soporte</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <button onClick={() => handleLinkClick('Centro de Ayuda')} className="text-zinc-400 hover:text-yellow-400 transition-colors">
                  Centro de Ayuda
                </button>
              </li>
              <li>
                <button onClick={() => handleLinkClick('Términos y Condiciones')} className="text-zinc-400 hover:text-yellow-400 transition-colors">
                  Términos y Condiciones
                </button>
              </li>
              <li>
                <button onClick={() => handleLinkClick('Política de Privacidad')} className="text-zinc-400 hover:text-yellow-400 transition-colors">
                  Política de Privacidad
                </button>
              </li>
              <li>
                <button onClick={() => handleLinkClick('Juego Responsable')} className="text-zinc-400 hover:text-yellow-400 transition-colors">
                  Juego Responsable
                </button>
              </li>
              <li>
                <button onClick={() => handleLinkClick('Verificación de Cuenta')} className="text-zinc-400 hover:text-yellow-400 transition-colors">
                  Verificación de Cuenta
                </button>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-white font-bold mb-4">Contacto</h3>
            <ul className="space-y-2 text-sm">
              <li className="flex items-start gap-2">
                <Mail className="w-4 h-4 mt-0.5 flex-shrink-0 text-yellow-500" />
                <a 
                  href="mailto:alejandrogarcia12345678910e@gmail.com"
                  className="hover:text-yellow-400 transition-colors break-all"
                >
                  alejandrogarcia12345678910e@gmail.com
                </a>
              </li>
              <li className="flex items-start gap-2">
                <Clock className="w-4 h-4 mt-0.5 flex-shrink-0 text-yellow-500" />
                <span>Soporte 24/7</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Certifications */}
        <div className="border-t border-zinc-800 pt-8 mb-8">
          <div className="flex flex-wrap items-center justify-center gap-6">
            <div className="bg-zinc-800 rounded-lg px-4 py-2 text-center">
              <p className="text-xs text-zinc-500">Licencia MGA</p>
              <p className="text-sm text-zinc-300 font-semibold">Malta Gaming</p>
            </div>
            <div className="bg-zinc-800 rounded-lg px-4 py-2 text-center">
              <p className="text-xs text-zinc-500">SSL Seguro</p>
              <p className="text-sm text-zinc-300 font-semibold">256-bit</p>
            </div>
            <div className="bg-zinc-800 rounded-lg px-4 py-2 text-center">
              <p className="text-xs text-zinc-500">Juego Seguro</p>
              <p className="text-sm text-zinc-300 font-semibold">+18</p>
            </div>
            <div className="bg-zinc-800 rounded-lg px-4 py-2 text-center">
              <p className="text-xs text-zinc-500">RNG Certificado</p>
              <p className="text-sm text-zinc-300 font-semibold">eCOGRA</p>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-zinc-800 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-sm text-zinc-500 text-center md:text-left">
              © 2026 AleandroGarsiajackpot. Todos los derechos reservados.
            </p>

            {/* Responsible Gaming */}
            <div className="flex items-center gap-4">
              <span className="text-sm text-zinc-500">+18</span>
              <span className="text-sm text-zinc-500">Juego Responsable</span>
            </div>
          </div>

          {/* Importante: Disclaimer de moneda virtual */}
          <div className="mt-6 bg-yellow-500/10 border border-yellow-500/30 rounded-lg p-4">
            <p className="text-center text-sm text-yellow-500 font-semibold">
              ⚠️ AVISO IMPORTANTE: Este casino utiliza exclusivamente "Fichas Jackpot" (moneda virtual sin valor monetario real).
              No se realizan pagos ni cobros reales. Todo el contenido es únicamente para entretenimiento. 
              Ninguna ganancia tiene valor económico fuera de la plataforma.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}