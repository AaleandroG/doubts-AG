import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';
import { Button } from './ui/button';
import { Play, Star, Info, TrendingUp } from 'lucide-react';
import { toast } from 'sonner';

interface GameModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  game: {
    title: string;
    image: string;
    category?: string;
    provider?: string;
  } | null;
}

export function GameModal({ open, onOpenChange, game }: GameModalProps) {
  if (!game) return null;

  const handlePlayForReal = () => {
    toast.info('Redirigiendo al juego...', {
      description: 'Abriendo ' + game.title,
    });
    onOpenChange(false);
  };

  const handlePlayDemo = () => {
    toast.success('Modo demo activado', {
      description: 'Juega gratis sin apostar dinero real',
    });
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl bg-zinc-900 border-zinc-800">
        <DialogHeader>
          <DialogTitle className="text-2xl text-white">
            {game.title}
          </DialogTitle>
          <DialogDescription className="text-zinc-400">
            {game.category || game.provider || 'Casino Game'}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Game Image */}
          <div className="relative rounded-xl overflow-hidden aspect-video">
            <img
              src={game.image}
              alt={game.title}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent"></div>
          </div>

          {/* Game Info */}
          <div className="grid grid-cols-3 gap-4">
            <div className="bg-zinc-800 rounded-lg p-4 text-center">
              <Star className="w-6 h-6 text-yellow-500 mx-auto mb-2" />
              <p className="text-sm text-zinc-400">Rating</p>
              <p className="text-lg font-bold text-white">4.8</p>
            </div>
            <div className="bg-zinc-800 rounded-lg p-4 text-center">
              <TrendingUp className="w-6 h-6 text-green-500 mx-auto mb-2" />
              <p className="text-sm text-zinc-400">RTP</p>
              <p className="text-lg font-bold text-white">96.5%</p>
            </div>
            <div className="bg-zinc-800 rounded-lg p-4 text-center">
              <Info className="w-6 h-6 text-blue-500 mx-auto mb-2" />
              <p className="text-sm text-zinc-400">Volatilidad</p>
              <p className="text-lg font-bold text-white">Media</p>
            </div>
          </div>

          {/* Description */}
          <div className="bg-zinc-800/50 rounded-lg p-4">
            <h4 className="text-white font-semibold mb-2">Acerca del juego</h4>
            <p className="text-sm text-zinc-400">
              Disfruta de una experiencia de juego emocionante con gráficos de alta calidad,
              múltiples líneas de pago y funciones de bonificación. Este juego ofrece
              entretenimiento premium con grandes oportunidades de ganar.
            </p>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3">
            <Button
              onClick={handlePlayForReal}
              className="flex-1 bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-black font-bold"
              size="lg"
            >
              <Play className="w-5 h-5 mr-2 fill-current" />
              Jugar con Dinero Real
            </Button>
            <Button
              onClick={handlePlayDemo}
              variant="outline"
              className="flex-1 border-zinc-700 text-white hover:bg-zinc-800"
              size="lg"
            >
              Jugar Demo
            </Button>
          </div>

          <p className="text-xs text-center text-zinc-500">
            Juego responsable. Solo para mayores de 18 años.
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}
